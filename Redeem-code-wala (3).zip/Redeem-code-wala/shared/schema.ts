import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const admins = pgTable("admins", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const redeemCodes = pgTable("redeem_codes", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  code: text("code").notNull(),
  denomination: integer("denomination").notNull(),
  isRedeemed: boolean("is_redeemed").default(false).notNull(),
  redeemedBy: varchar("redeemed_by"),
  redeemedAt: timestamp("redeemed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: varchar("created_by").notNull(),
});

export const appUsers = pgTable("app_users", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  deviceId: text("device_id").notNull().unique(),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: text("referred_by"),
  tokenBalance: integer("token_balance").default(100).notNull(),
  totalEarned: integer("total_earned").default(100).notNull(),
  totalSpent: integer("total_spent").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const redemptionHistory = pgTable("redemption_history", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  codeId: varchar("code_id").notNull(),
  denomination: integer("denomination").notNull(),
  code: text("code").notNull(),
  redeemedAt: timestamp("redeemed_at").defaultNow().notNull(),
});

export const blockedUsers = pgTable("blocked_users", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  uid: text("uid").notNull().unique(),
  reason: text("reason"),
  blockType: text("block_type").default("misbehave"),
  blockedAt: timestamp("blocked_at").defaultNow().notNull(),
  blockedBy: varchar("blocked_by").notNull(),
});

export const inboxMessages = pgTable("inbox_messages", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  uid: text("uid").notNull(),
  type: text("type").notNull().default("token_gift"),
  title: text("title").notNull(),
  message: text("message").notNull(),
  tokens: integer("tokens").default(0),
  claimed: boolean("claimed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  sentBy: varchar("sent_by"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertAdminSchema = createInsertSchema(admins).pick({
  email: true,
  password: true,
});

export const insertRedeemCodeSchema = createInsertSchema(redeemCodes).pick({
  code: true,
  denomination: true,
  createdBy: true,
});

export const insertAppUserSchema = createInsertSchema(appUsers).pick({
  deviceId: true,
  referralCode: true,
  referredBy: true,
});

export const insertBlockedUserSchema = createInsertSchema(blockedUsers).pick({
  uid: true,
  reason: true,
  blockedBy: true,
});

export const insertInboxMessageSchema = createInsertSchema(inboxMessages).pick({
  uid: true,
  type: true,
  title: true,
  message: true,
  tokens: true,
  sentBy: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type RedeemCode = typeof redeemCodes.$inferSelect;
export type InsertRedeemCode = z.infer<typeof insertRedeemCodeSchema>;
export type AppUser = typeof appUsers.$inferSelect;
export type InsertAppUser = z.infer<typeof insertAppUserSchema>;
export type RedemptionHistory = typeof redemptionHistory.$inferSelect;
export type BlockedUser = typeof blockedUsers.$inferSelect;
export type InsertBlockedUser = z.infer<typeof insertBlockedUserSchema>;
export type InboxMessage = typeof inboxMessages.$inferSelect;
export type InsertInboxMessage = z.infer<typeof insertInboxMessageSchema>;
