# REDEEM CODE WALA

## Overview

REDEEM CODE WALA is a cross-platform mobile rewards application built with Expo/React Native. Users earn tokens through daily check-ins and playing games, then redeem those tokens for reward codes. The app features a referral system to incentivize user growth.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Expo SDK 54 with React Native 0.81
- **Navigation**: React Navigation v7 with a nested navigator structure
  - Root Stack Navigator handles authentication flow (Login → Main)
  - Main Tab Navigator provides bottom tab navigation across 5 sections (Dashboard, Games, Rewards, Referral, Profile)
  - Each tab has its own Stack Navigator for potential deep navigation
- **State Management**: TanStack React Query for server state, local React state for UI
- **Animations**: React Native Reanimated for smooth, performant animations
- **Styling**: Dark theme by default with a custom theme system using constants

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **API Pattern**: RESTful routes prefixed with `/api`
- **Storage Layer**: Abstracted storage interface (`IStorage`) with in-memory implementation (`MemStorage`) - can be swapped for database implementation

### Data Storage Solutions
- **Server-side**: PostgreSQL database (Drizzle ORM for schema management and queries)
- **Client-side**: AsyncStorage for persisting user data, tokens, check-ins, rewards history, and game sessions locally
- **Schema**: Currently defines a `users` table with id, username, and password fields

### Key Design Patterns
- Path aliases (`@/` for client, `@shared/` for shared code) for clean imports
- Separation of concerns: client code in `/client`, server in `/server`, shared schemas in `/shared`
- Component-driven UI with reusable themed components (ThemedText, ThemedView, Button, Card variants)
- Custom hooks for theme, screen options, and color scheme handling

## External Dependencies

### Third-Party Services & APIs
- None currently configured - app uses local storage for data persistence

### Database
- **PostgreSQL**: Primary database configured via `DATABASE_URL` environment variable
- **Drizzle ORM**: Schema-first approach with Zod integration for validation

### Key Libraries
- **expo-haptics**: Tactile feedback for user interactions
- **expo-clipboard**: Copy functionality for referral codes and reward codes
- **react-native-webview**: Embedded game playing experience
- **expo-linear-gradient**: Premium visual effects for cards and UI elements
- **@tanstack/react-query**: Data fetching and caching layer

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `EXPO_PUBLIC_DOMAIN`: API server domain for client-server communication
- `REPLIT_DEV_DOMAIN`: Development domain (Replit-specific)