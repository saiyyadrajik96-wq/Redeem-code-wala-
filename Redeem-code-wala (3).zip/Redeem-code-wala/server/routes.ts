import type { Express } from "express";
import { createServer, type Server } from "node:http";
import { storage } from "./storage";

const ADMIN_EMAIL = "saiyyadrajik96@gmail.com";
const ADMIN_PASSWORD = "aksa@123";

export async function registerRoutes(app: Express): Promise<Server> {
  
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }
      
      if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      let admin = await storage.getAdminByEmail(email);
      
      if (!admin) {
        admin = await storage.createAdmin({ email, password });
      }
      
      res.json({ success: true, admin: { id: admin.id, email: admin.email } });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.get("/api/admin/codes", async (req, res) => {
    try {
      const codes = await storage.getAllCodes();
      res.json(codes);
    } catch (error) {
      console.error("Get codes error:", error);
      res.status(500).json({ error: "Failed to fetch codes" });
    }
  });

  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = await storage.getCodeStats();
      res.json(stats);
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  app.post("/api/admin/codes", async (req, res) => {
    try {
      const { code, denomination, adminId } = req.body;
      
      if (!code || !denomination || !adminId) {
        return res.status(400).json({ error: "Code, denomination, and adminId required" });
      }
      
      const newCode = await storage.createRedeemCode({
        code,
        denomination: parseInt(denomination),
        createdBy: adminId,
      });
      
      res.json(newCode);
    } catch (error) {
      console.error("Create code error:", error);
      res.status(500).json({ error: "Failed to create code" });
    }
  });

  app.delete("/api/admin/codes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteCode(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Code not found or already redeemed" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Delete code error:", error);
      res.status(500).json({ error: "Failed to delete code" });
    }
  });

  app.get("/api/rewards/stock", async (req, res) => {
    try {
      const stats = await storage.getCodeStats();
      const stockInfo = [10, 50, 100, 500].map((denom) => {
        const stat = stats.find((s) => s.denomination === denom);
        return {
          denomination: denom,
          available: stat?.available || 0,
          tokenCost: denom * 10,
        };
      });
      res.json(stockInfo);
    } catch (error) {
      console.error("Get stock error:", error);
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  app.post("/api/rewards/redeem", async (req, res) => {
    try {
      const { deviceId, denomination } = req.body;
      
      if (!deviceId || !denomination) {
        return res.status(400).json({ error: "DeviceId and denomination required" });
      }
      
      const availableCodes = await storage.getAvailableCodes(parseInt(denomination));
      
      if (availableCodes.length === 0) {
        return res.status(400).json({ error: "No codes available for this denomination" });
      }
      
      const codeToRedeem = availableCodes[0];
      const redeemedCode = await storage.redeemCode(codeToRedeem.id, deviceId);
      
      if (!redeemedCode) {
        return res.status(400).json({ error: "Failed to redeem code" });
      }
      
      res.json({
        success: true,
        code: redeemedCode.code,
        denomination: redeemedCode.denomination,
      });
    } catch (error) {
      console.error("Redeem error:", error);
      res.status(500).json({ error: "Failed to redeem code" });
    }
  });

  app.get("/api/user/:deviceId/history", async (req, res) => {
    try {
      const { deviceId } = req.params;
      const history = await storage.getUserRedemptionHistory(deviceId);
      res.json(history);
    } catch (error) {
      console.error("Get history error:", error);
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllAppUsers();
      res.json(users);
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/blocked", async (req, res) => {
    try {
      const blockedUsers = await storage.getBlockedUsers();
      res.json(blockedUsers);
    } catch (error) {
      console.error("Get blocked users error:", error);
      res.status(500).json({ error: "Failed to fetch blocked users" });
    }
  });

  app.post("/api/admin/block", async (req, res) => {
    try {
      const { uid, reason, adminId, blockType } = req.body;
      
      if (!uid || !adminId) {
        return res.status(400).json({ error: "UID and adminId required" });
      }
      
      const isAlreadyBlocked = await storage.isUserBlocked(uid);
      if (isAlreadyBlocked) {
        return res.status(400).json({ error: "User already blocked" });
      }

      const BLOCK_MESSAGES: Record<string, string> = {
        misbehave: "Account Blocked: Aapke dwara kiye gaye galat vyavahar (misbehave) aur hamari community guidelines ka ullanghan karne ke kaaran aapka account permanently block kar diya gaya hai. Hamari team se sampark na karen.",
        mod_apk: "Security Alert: Humne detect kiya hai ki aap modded APK (hacked version) ka istemaal kar rahe hain. App ki suraksha ke liye aapko block kar diya gaya hai. Kripya Play Store se official app download karen.",
        third_party: "Access Denied: Yeh app Google Play Store se install nahi ki gayi hai. Suraksha kaaranon se, unverified sources se install ki gayi apps ko block kar diya gaya hai. Valid version install karen.",
      };

      const type = blockType || "misbehave";
      const blockMessage = BLOCK_MESSAGES[type] || reason || "Blocked by admin";
      
      const blocked = await storage.blockUser({
        uid,
        reason: blockMessage,
        blockedBy: adminId,
        blockType: type,
      });

      await storage.createInboxMessage({
        uid,
        type: "block_warning",
        title: "Account Blocked",
        message: blockMessage,
        tokens: 0,
        sentBy: adminId,
      });
      
      res.json({ success: true, blocked });
    } catch (error) {
      console.error("Block user error:", error);
      res.status(500).json({ error: "Failed to block user" });
    }
  });

  app.post("/api/admin/unblock", async (req, res) => {
    try {
      const { uid } = req.body;
      
      if (!uid) {
        return res.status(400).json({ error: "UID required" });
      }
      
      const unblocked = await storage.unblockUser(uid);
      
      if (!unblocked) {
        return res.status(404).json({ error: "User not found in blocked list" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Unblock user error:", error);
      res.status(500).json({ error: "Failed to unblock user" });
    }
  });

  app.get("/api/user/blocked/:uid", async (req, res) => {
    try {
      const { uid } = req.params;
      const isBlocked = await storage.isUserBlocked(uid);
      let blockInfo = null;
      if (isBlocked) {
        blockInfo = await storage.getBlockedUserInfo(uid);
      }
      res.json({ blocked: isBlocked, blockInfo });
    } catch (error) {
      console.error("Check blocked error:", error);
      res.status(500).json({ error: "Failed to check blocked status" });
    }
  });

  app.post("/api/admin/send-tokens", async (req, res) => {
    try {
      const { uid, tokens, adminId } = req.body;
      
      if (!uid || !tokens || !adminId) {
        return res.status(400).json({ error: "UID, tokens, and adminId required" });
      }
      
      const tokenAmount = parseInt(tokens);
      if (isNaN(tokenAmount) || tokenAmount <= 0) {
        return res.status(400).json({ error: "Invalid token amount" });
      }
      
      const user = await storage.getAppUserByReferralCode(uid);
      if (!user) {
        return res.status(404).json({ error: "User not found with this UID" });
      }
      
      const inboxMsg = await storage.createInboxMessage({
        uid: uid,
        type: "token_gift",
        title: "Admin Token Gift",
        message: `Admin ne aapko ${tokenAmount} tokens bheje hain! Claim karne ke liye tap karein.`,
        tokens: tokenAmount,
        sentBy: adminId,
      });
      
      res.json({ success: true, message: inboxMsg });
    } catch (error) {
      console.error("Send tokens error:", error);
      res.status(500).json({ error: "Failed to send tokens" });
    }
  });

  app.get("/api/user/inbox/:uid", async (req, res) => {
    try {
      const { uid } = req.params;
      const messages = await storage.getInboxMessages(uid);
      res.json(messages);
    } catch (error) {
      console.error("Get inbox error:", error);
      res.status(500).json({ error: "Failed to fetch inbox" });
    }
  });

  app.post("/api/user/inbox/claim/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { uid } = req.body;
      
      const claimed = await storage.claimInboxMessage(id);
      if (!claimed) {
        return res.status(400).json({ error: "Message already claimed or not found" });
      }
      
      if (claimed.tokens && claimed.tokens > 0 && uid) {
        await storage.updateUserTokenBalance(uid, claimed.tokens);
      }
      
      res.json({ success: true, tokens: claimed.tokens });
    } catch (error) {
      console.error("Claim inbox error:", error);
      res.status(500).json({ error: "Failed to claim" });
    }
  });

  app.get("/api/user/inbox/count/:uid", async (req, res) => {
    try {
      const { uid } = req.params;
      const count = await storage.getUnclaimedCount(uid);
      res.json({ count });
    } catch (error) {
      console.error("Get inbox count error:", error);
      res.status(500).json({ error: "Failed to get count" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
