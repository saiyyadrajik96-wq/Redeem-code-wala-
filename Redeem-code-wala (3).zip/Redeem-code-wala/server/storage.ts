import { eq, and, asc, desc } from "drizzle-orm";
import { db } from "./db";
import {
  admins,
  redeemCodes,
  appUsers,
  redemptionHistory,
  blockedUsers,
  inboxMessages,
  type Admin,
  type InsertAdmin,
  type RedeemCode,
  type InsertRedeemCode,
  type AppUser,
  type InsertAppUser,
  type RedemptionHistory,
  type BlockedUser,
  type InsertBlockedUser,
  type InboxMessage,
  type InsertInboxMessage,
} from "@shared/schema";

export interface IStorage {
  getAdminByEmail(email: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  
  getAvailableCodes(denomination: number): Promise<RedeemCode[]>;
  getAllCodes(): Promise<RedeemCode[]>;
  getCodeStats(): Promise<{ denomination: number; available: number; redeemed: number }[]>;
  createRedeemCode(code: InsertRedeemCode): Promise<RedeemCode>;
  redeemCode(codeId: string, userId: string): Promise<RedeemCode | null>;
  deleteCode(codeId: string): Promise<boolean>;
  
  getAppUser(deviceId: string): Promise<AppUser | undefined>;
  getAllAppUsers(): Promise<AppUser[]>;
  createAppUser(user: InsertAppUser): Promise<AppUser>;
  updateUserTokens(deviceId: string, balance: number, totalSpent: number): Promise<AppUser | null>;
  
  getUserRedemptionHistory(userId: string): Promise<RedemptionHistory[]>;
  
  isUserBlocked(uid: string): Promise<boolean>;
  getBlockedUserInfo(uid: string): Promise<BlockedUser | undefined>;
  blockUser(data: InsertBlockedUser & { blockType?: string }): Promise<BlockedUser>;
  unblockUser(uid: string): Promise<boolean>;
  getBlockedUsers(): Promise<BlockedUser[]>;
  
  getInboxMessages(uid: string): Promise<InboxMessage[]>;
  createInboxMessage(msg: InsertInboxMessage): Promise<InboxMessage>;
  claimInboxMessage(id: string): Promise<InboxMessage | null>;
  getUnclaimedCount(uid: string): Promise<number>;
  
  getAppUserByReferralCode(referralCode: string): Promise<AppUser | undefined>;
  updateUserTokenBalance(referralCode: string, tokensToAdd: number): Promise<AppUser | null>;
}

export class DatabaseStorage implements IStorage {
  async getAdminByEmail(email: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.email, email));
    return admin;
  }

  async createAdmin(admin: InsertAdmin): Promise<Admin> {
    const [newAdmin] = await db.insert(admins).values(admin).returning();
    return newAdmin;
  }

  async getAvailableCodes(denomination: number): Promise<RedeemCode[]> {
    return db
      .select()
      .from(redeemCodes)
      .where(
        and(
          eq(redeemCodes.denomination, denomination),
          eq(redeemCodes.isRedeemed, false)
        )
      )
      .orderBy(asc(redeemCodes.createdAt));
  }

  async getAllCodes(): Promise<RedeemCode[]> {
    return db.select().from(redeemCodes).orderBy(asc(redeemCodes.createdAt));
  }

  async getCodeStats(): Promise<{ denomination: number; available: number; redeemed: number }[]> {
    const allCodes = await this.getAllCodes();
    const stats: Map<number, { available: number; redeemed: number }> = new Map();
    
    for (const code of allCodes) {
      const current = stats.get(code.denomination) || { available: 0, redeemed: 0 };
      if (code.isRedeemed) {
        current.redeemed++;
      } else {
        current.available++;
      }
      stats.set(code.denomination, current);
    }
    
    return Array.from(stats.entries())
      .map(([denomination, counts]) => ({
        denomination,
        ...counts,
      }))
      .sort((a, b) => a.denomination - b.denomination);
  }

  async createRedeemCode(code: InsertRedeemCode): Promise<RedeemCode> {
    const [newCode] = await db.insert(redeemCodes).values(code).returning();
    return newCode;
  }

  async redeemCode(codeId: string, userId: string): Promise<RedeemCode | null> {
    const [updated] = await db
      .update(redeemCodes)
      .set({
        isRedeemed: true,
        redeemedBy: userId,
        redeemedAt: new Date(),
      })
      .where(and(eq(redeemCodes.id, codeId), eq(redeemCodes.isRedeemed, false)))
      .returning();
    
    if (updated) {
      await db.insert(redemptionHistory).values({
        userId,
        codeId: updated.id,
        denomination: updated.denomination,
        code: updated.code,
      });
    }
    
    return updated || null;
  }

  async deleteCode(codeId: string): Promise<boolean> {
    const result = await db
      .delete(redeemCodes)
      .where(and(eq(redeemCodes.id, codeId), eq(redeemCodes.isRedeemed, false)))
      .returning();
    return result.length > 0;
  }

  async getAppUser(deviceId: string): Promise<AppUser | undefined> {
    const [user] = await db.select().from(appUsers).where(eq(appUsers.deviceId, deviceId));
    return user;
  }

  async getAllAppUsers(): Promise<AppUser[]> {
    return db.select().from(appUsers).orderBy(desc(appUsers.createdAt));
  }

  async createAppUser(user: InsertAppUser): Promise<AppUser> {
    const [newUser] = await db.insert(appUsers).values(user).returning();
    return newUser;
  }

  async updateUserTokens(deviceId: string, balance: number, totalSpent: number): Promise<AppUser | null> {
    const [updated] = await db
      .update(appUsers)
      .set({ tokenBalance: balance, totalSpent })
      .where(eq(appUsers.deviceId, deviceId))
      .returning();
    return updated || null;
  }

  async getUserRedemptionHistory(userId: string): Promise<RedemptionHistory[]> {
    return db
      .select()
      .from(redemptionHistory)
      .where(eq(redemptionHistory.userId, userId))
      .orderBy(asc(redemptionHistory.redeemedAt));
  }

  async isUserBlocked(uid: string): Promise<boolean> {
    const [blocked] = await db.select().from(blockedUsers).where(eq(blockedUsers.uid, uid));
    return !!blocked;
  }

  async getBlockedUserInfo(uid: string): Promise<BlockedUser | undefined> {
    const [blocked] = await db.select().from(blockedUsers).where(eq(blockedUsers.uid, uid));
    return blocked;
  }

  async blockUser(data: InsertBlockedUser & { blockType?: string }): Promise<BlockedUser> {
    const [blocked] = await db.insert(blockedUsers).values({
      uid: data.uid,
      reason: data.reason,
      blockedBy: data.blockedBy,
      blockType: data.blockType || "misbehave",
    } as any).returning();
    return blocked;
  }

  async unblockUser(uid: string): Promise<boolean> {
    const result = await db.delete(blockedUsers).where(eq(blockedUsers.uid, uid)).returning();
    return result.length > 0;
  }

  async getBlockedUsers(): Promise<BlockedUser[]> {
    return db.select().from(blockedUsers).orderBy(desc(blockedUsers.blockedAt));
  }

  async getInboxMessages(uid: string): Promise<InboxMessage[]> {
    return db.select().from(inboxMessages).where(eq(inboxMessages.uid, uid)).orderBy(desc(inboxMessages.createdAt));
  }

  async createInboxMessage(msg: InsertInboxMessage): Promise<InboxMessage> {
    const [newMsg] = await db.insert(inboxMessages).values(msg).returning();
    return newMsg;
  }

  async claimInboxMessage(id: string): Promise<InboxMessage | null> {
    const [updated] = await db
      .update(inboxMessages)
      .set({ claimed: true })
      .where(and(eq(inboxMessages.id, id), eq(inboxMessages.claimed, false)))
      .returning();
    return updated || null;
  }

  async getUnclaimedCount(uid: string): Promise<number> {
    const msgs = await db
      .select()
      .from(inboxMessages)
      .where(and(eq(inboxMessages.uid, uid), eq(inboxMessages.claimed, false)));
    return msgs.length;
  }

  async getAppUserByReferralCode(referralCode: string): Promise<AppUser | undefined> {
    const [user] = await db.select().from(appUsers).where(eq(appUsers.referralCode, referralCode));
    return user;
  }

  async updateUserTokenBalance(referralCode: string, tokensToAdd: number): Promise<AppUser | null> {
    const user = await this.getAppUserByReferralCode(referralCode);
    if (!user) return null;
    const [updated] = await db
      .update(appUsers)
      .set({ 
        tokenBalance: user.tokenBalance + tokensToAdd,
        totalEarned: user.totalEarned + tokensToAdd,
      })
      .where(eq(appUsers.referralCode, referralCode))
      .returning();
    return updated || null;
  }
}

export const storage = new DatabaseStorage();
