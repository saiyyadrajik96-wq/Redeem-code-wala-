import React from "react";
import { View, StyleSheet, Pressable, ActivityIndicator } from "react-native";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  withTiming,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";

interface CheckinButtonProps {
  streak: number;
  canCheckin: boolean;
  onCheckin: () => void;
  loading?: boolean;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function CheckinButton({
  streak,
  canCheckin,
  onCheckin,
  loading = false,
}: CheckinButtonProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    if (canCheckin && !loading) {
      scale.value = withSpring(0.95);
    }
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  const handlePress = () => {
    if (canCheckin && !loading) {
      scale.value = withSequence(
        withTiming(1.05, { duration: 100 }),
        withSpring(1)
      );
      onCheckin();
    }
  };

  return (
    <AnimatedPressable
      onPress={handlePress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={animatedStyle}
    >
      <LinearGradient
        colors={
          canCheckin
            ? [DiamondColors.gold, DiamondColors.goldDark]
            : [theme.backgroundDefault, theme.backgroundSecondary]
        }
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[
          styles.container,
          { borderColor: canCheckin ? DiamondColors.gold : theme.cardBorder },
        ]}
      >
        <View style={styles.leftContent}>
          <View style={styles.iconContainer}>
            {loading ? (
              <ActivityIndicator size="small" color={canCheckin ? "#1A1A2E" : theme.text} />
            ) : (
              <Feather
                name={canCheckin ? "gift" : "check-circle"}
                size={24}
                color={canCheckin ? "#1A1A2E" : theme.success}
              />
            )}
          </View>
          <View>
            <ThemedText
              style={[
                styles.title,
                { color: canCheckin ? "#1A1A2E" : theme.text },
              ]}
            >
              {canCheckin ? "Daily Check-in" : "Checked In!"}
            </ThemedText>
            <ThemedText
              style={[
                styles.subtitle,
                { color: canCheckin ? "#1A1A2E99" : theme.textSecondary },
              ]}
            >
              {canCheckin
                ? `Claim ${50 + Math.min(streak, 6) * 10} tokens`
                : "Come back tomorrow"}
            </ThemedText>
          </View>
        </View>

        <View
          style={[
            styles.streakBadge,
            {
              backgroundColor: canCheckin
                ? "rgba(26, 26, 46, 0.15)"
                : theme.backgroundTertiary,
            },
          ]}
        >
          <Feather
            name="zap"
            size={14}
            color={canCheckin ? "#1A1A2E" : theme.gold}
          />
          <ThemedText
            style={[
              styles.streakText,
              { color: canCheckin ? "#1A1A2E" : theme.gold },
            ]}
          >
            {streak} Day Streak
          </ThemedText>
        </View>
      </LinearGradient>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
  },
  leftContent: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  },
  title: {
    fontSize: 16,
    fontWeight: "700",
  },
  subtitle: {
    fontSize: 12,
    marginTop: 2,
  },
  streakBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  streakText: {
    fontSize: 12,
    fontWeight: "600",
  },
});
