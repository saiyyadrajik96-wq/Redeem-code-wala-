import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";

interface RewardCardProps {
  denomination: number;
  tokenCost: number;
  stock: number;
  onPress: () => void;
  disabled?: boolean;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function RewardCard({
  denomination,
  tokenCost,
  stock,
  onPress,
  disabled = false,
}: RewardCardProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);
  const outOfStock = stock <= 0;
  const isDisabled = disabled || outOfStock;

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: isDisabled ? 0.5 : 1,
  }));

  const handlePressIn = () => {
    if (!isDisabled) {
      scale.value = withSpring(0.95);
    }
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  const getStockColor = () => {
    if (stock <= 0) return theme.error;
    if (stock <= 10) return theme.warning;
    return theme.success;
  };

  return (
    <AnimatedPressable
      onPress={isDisabled ? undefined : onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[styles.container, animatedStyle]}
    >
      <LinearGradient
        colors={
          outOfStock
            ? [theme.backgroundDefault, theme.backgroundSecondary]
            : ["rgba(255, 215, 0, 0.12)", "rgba(10, 132, 255, 0.08)"]
        }
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[
          styles.card,
          {
            borderColor: outOfStock
              ? theme.cardBorder
              : "rgba(255, 215, 0, 0.25)",
          },
        ]}
      >
        <View style={styles.header}>
          <View style={[styles.stockBadge, { backgroundColor: getStockColor() + "20" }]}>
            <ThemedText style={[styles.stockText, { color: getStockColor() }]}>
              {stock > 0 ? `${stock} left` : "Out of Stock"}
            </ThemedText>
          </View>
        </View>

        <View style={styles.content}>
          <View style={styles.denominationRow}>
            <ThemedText style={[styles.currency, { color: theme.gold }]}>
              Rs
            </ThemedText>
            <ThemedText style={[styles.denomination, { color: theme.text }]}>
              {denomination}
            </ThemedText>
          </View>
          <ThemedText style={[styles.label, { color: theme.textSecondary }]}>
            Google Play Code
          </ThemedText>
        </View>

        <View style={styles.footer}>
          <View style={styles.costContainer}>
            <Feather name="hexagon" size={14} color={theme.gold} />
            <ThemedText style={[styles.cost, { color: theme.gold }]}>
              {tokenCost.toLocaleString()}
            </ThemedText>
          </View>
          {!outOfStock ? (
            <View style={[styles.redeemButton, { backgroundColor: theme.primary }]}>
              <ThemedText style={styles.redeemText}>Redeem</ThemedText>
            </View>
          ) : null}
        </View>
      </LinearGradient>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    minHeight: 160,
    justifyContent: "space-between",
  },
  header: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  stockBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  stockText: {
    fontSize: 10,
    fontWeight: "600",
  },
  content: {
    alignItems: "center",
  },
  denominationRow: {
    flexDirection: "row",
    alignItems: "baseline",
  },
  currency: {
    fontSize: 16,
    fontWeight: "600",
    marginRight: 4,
  },
  denomination: {
    fontSize: 36,
    fontWeight: "800",
  },
  label: {
    fontSize: 12,
    marginTop: 4,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  costContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  cost: {
    fontSize: 14,
    fontWeight: "700",
  },
  redeemButton: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  redeemText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#FFFFFF",
  },
});
