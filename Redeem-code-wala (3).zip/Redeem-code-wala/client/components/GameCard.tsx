import React from "react";
import { View, StyleSheet, Pressable, ImageBackground } from "react-native";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";

interface GameCardProps {
  name: string;
  category: string;
  tokensPerMin: number;
  iconName: keyof typeof Feather.glyphMap;
  color: string;
  onPress: () => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function GameCard({
  name,
  category,
  tokensPerMin,
  iconName,
  color,
  onPress,
}: GameCardProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.95);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[styles.container, animatedStyle]}
    >
      <LinearGradient
        colors={[color + "30", color + "10"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.card, { borderColor: color + "40" }]}
      >
        <View style={[styles.iconContainer, { backgroundColor: color }]}>
          <Feather name={iconName} size={24} color="#FFFFFF" />
        </View>
        
        <View style={styles.content}>
          <ThemedText style={styles.name} numberOfLines={1}>
            {name}
          </ThemedText>
          <ThemedText style={[styles.category, { color: theme.textSecondary }]}>
            {category}
          </ThemedText>
        </View>

        <View style={styles.rewardBadge}>
          <Feather name="hexagon" size={12} color={theme.gold} />
          <ThemedText style={[styles.rewardText, { color: theme.gold }]}>
            +{tokensPerMin}/min
          </ThemedText>
        </View>
      </LinearGradient>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    minHeight: 140,
    justifyContent: "space-between",
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    marginTop: Spacing.sm,
  },
  name: {
    fontSize: 14,
    fontWeight: "600",
  },
  category: {
    fontSize: 12,
    marginTop: 2,
  },
  rewardBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: Spacing.sm,
  },
  rewardText: {
    fontSize: 12,
    fontWeight: "600",
  },
});
