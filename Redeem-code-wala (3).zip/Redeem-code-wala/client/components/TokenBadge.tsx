import React from "react";
import { View, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";

interface TokenBadgeProps {
  balance: number;
  size?: "small" | "large";
}

export function TokenBadge({ balance, size = "small" }: TokenBadgeProps) {
  const { theme } = useTheme();
  const isLarge = size === "large";

  return (
    <LinearGradient
      colors={[DiamondColors.gold, DiamondColors.goldDark]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[styles.container, isLarge ? styles.containerLarge : null]}
    >
      <Feather
        name="hexagon"
        size={isLarge ? 24 : 16}
        color="#1A1A2E"
      />
      <ThemedText
        style={[
          styles.text,
          isLarge ? styles.textLarge : null,
          { color: "#1A1A2E" },
        ]}
      >
        {balance.toLocaleString()}
      </ThemedText>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    gap: Spacing.xs,
  },
  containerLarge: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
  },
  text: {
    fontSize: 14,
    fontWeight: "700",
  },
  textLarge: {
    fontSize: 24,
  },
});
