import React, { useState, useEffect } from "react";
import { View, StyleSheet, Share, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import * as Clipboard from "expo-clipboard";

import { ThemedText } from "@/components/ThemedText";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { DiamondCard } from "@/components/DiamondCard";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";
import { getUser, UserData } from "@/lib/storage";

const REFERRAL_REWARDS = [
  { level: 1, referrals: 1, bonus: 100 },
  { level: 2, referrals: 5, bonus: 600 },
  { level: 3, referrals: 10, bonus: 1500 },
  { level: 4, referrals: 25, bonus: 4000 },
  { level: 5, referrals: 50, bonus: 10000 },
];

export default function ReferralScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [user, setUser] = useState<UserData | null>(null);
  const [referralCount] = useState(0);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const userData = await getUser();
    setUser(userData);
  };

  const handleShare = async () => {
    if (!user) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const message = `Join REDEEM CODE WALA and earn rewards! Use my referral code: ${user.referralCode}\n\nDownload now and get 100 bonus tokens!`;

    try {
      await Share.share({
        message,
        title: "Invite to REDEEM CODE WALA",
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleCopyCode = async () => {
    if (!user) return;
    await Clipboard.setStringAsync(user.referralCode);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const getCurrentLevel = () => {
    for (let i = REFERRAL_REWARDS.length - 1; i >= 0; i--) {
      if (referralCount >= REFERRAL_REWARDS[i].referrals) {
        return i + 1;
      }
    }
    return 0;
  };

  const getNextReward = () => {
    const currentLevel = getCurrentLevel();
    if (currentLevel >= REFERRAL_REWARDS.length) return null;
    return REFERRAL_REWARDS[currentLevel];
  };

  const nextReward = getNextReward();

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.xl,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
    >
      <LinearGradient
        colors={["rgba(10, 132, 255, 0.15)", "rgba(255, 215, 0, 0.08)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.heroCard}
      >
        <View style={[styles.iconContainer, { backgroundColor: theme.primary + "30" }]}>
          <Feather name="users" size={32} color={theme.primary} />
        </View>
        <ThemedText type="h3" style={styles.heroTitle}>
          Refer & Earn
        </ThemedText>
        <ThemedText style={[styles.heroText, { color: theme.textSecondary }]}>
          Invite friends and earn bonus tokens when they join!
        </ThemedText>
      </LinearGradient>

      <View style={styles.section}>
        <ThemedText type="h4" style={styles.sectionTitle}>
          Your Referral Code
        </ThemedText>

        <DiamondCard variant="gold">
          <View style={styles.codeRow}>
            <ThemedText style={[styles.code, { color: theme.gold }]}>
              {user?.referralCode || "Loading..."}
            </ThemedText>
            <View style={styles.codeActions}>
              <Button onPress={handleCopyCode} style={styles.copyButton}>
                Copy
              </Button>
            </View>
          </View>
        </DiamondCard>

        <Button onPress={handleShare} style={styles.shareButton}>
          Share Invite Link
        </Button>
      </View>

      <View style={styles.section}>
        <View style={styles.statsRow}>
          <DiamondCard variant="primary" style={styles.statCard}>
            <ThemedText style={[styles.statValue, { color: theme.primary }]}>
              {referralCount}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Friends Referred
            </ThemedText>
          </DiamondCard>

          <DiamondCard variant="gold" style={styles.statCard}>
            <ThemedText style={[styles.statValue, { color: theme.gold }]}>
              {getCurrentLevel()}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Current Level
            </ThemedText>
          </DiamondCard>
        </View>
      </View>

      {nextReward ? (
        <View style={styles.section}>
          <DiamondCard variant="default">
            <View style={styles.progressHeader}>
              <ThemedText type="h4">Next Milestone</ThemedText>
              <View style={[styles.levelBadge, { backgroundColor: theme.primary + "20" }]}>
                <ThemedText style={[styles.levelText, { color: theme.primary }]}>
                  Level {nextReward.level}
                </ThemedText>
              </View>
            </View>

            <View style={styles.progressContainer}>
              <View
                style={[styles.progressBar, { backgroundColor: theme.backgroundTertiary }]}
              >
                <View
                  style={[
                    styles.progressFill,
                    {
                      backgroundColor: theme.primary,
                      width: `${Math.min(100, (referralCount / nextReward.referrals) * 100)}%`,
                    },
                  ]}
                />
              </View>
              <ThemedText style={[styles.progressText, { color: theme.textSecondary }]}>
                {referralCount} / {nextReward.referrals} referrals
              </ThemedText>
            </View>

            <View style={styles.rewardRow}>
              <Feather name="gift" size={18} color={theme.gold} />
              <ThemedText style={[styles.rewardText, { color: theme.gold }]}>
                +{nextReward.bonus} tokens bonus
              </ThemedText>
            </View>
          </DiamondCard>
        </View>
      ) : null}

      <View style={styles.section}>
        <ThemedText type="h4" style={styles.sectionTitle}>
          Reward Milestones
        </ThemedText>

        {REFERRAL_REWARDS.map((reward, index) => {
          const isCompleted = referralCount >= reward.referrals;
          const isCurrent = getCurrentLevel() === index;

          return (
            <View
              key={reward.level}
              style={[
                styles.milestoneItem,
                { borderColor: theme.cardBorder },
                isCompleted && { borderColor: theme.success + "40" },
              ]}
            >
              <View
                style={[
                  styles.milestoneIcon,
                  {
                    backgroundColor: isCompleted
                      ? theme.success + "20"
                      : theme.backgroundSecondary,
                  },
                ]}
              >
                <Feather
                  name={isCompleted ? "check" : "star"}
                  size={16}
                  color={isCompleted ? theme.success : theme.textSecondary}
                />
              </View>

              <View style={styles.milestoneContent}>
                <ThemedText
                  style={[
                    styles.milestoneName,
                    isCompleted && { color: theme.success },
                  ]}
                >
                  Level {reward.level} - {reward.referrals} Referrals
                </ThemedText>
                <View style={styles.milestoneReward}>
                  <Feather name="hexagon" size={12} color={theme.gold} />
                  <ThemedText style={[styles.milestoneBonus, { color: theme.gold }]}>
                    +{reward.bonus} tokens
                  </ThemedText>
                </View>
              </View>

              {isCompleted ? (
                <View style={[styles.completedBadge, { backgroundColor: theme.success + "20" }]}>
                  <ThemedText style={[styles.completedText, { color: theme.success }]}>
                    Claimed
                  </ThemedText>
                </View>
              ) : null}
            </View>
          );
        })}
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  heroCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: "rgba(10, 132, 255, 0.2)",
    alignItems: "center",
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  heroTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  heroText: {
    fontSize: 14,
    textAlign: "center",
  },
  section: {
    marginTop: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  codeRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  code: {
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: 2,
  },
  codeActions: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  copyButton: {
    paddingHorizontal: Spacing.lg,
    height: 40,
  },
  shareButton: {
    marginTop: Spacing.md,
  },
  statsRow: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  statCard: {
    flex: 1,
    alignItems: "center",
  },
  statValue: {
    fontSize: 32,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 12,
    marginTop: Spacing.xs,
  },
  progressHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: Spacing.lg,
  },
  levelBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  levelText: {
    fontSize: 12,
    fontWeight: "600",
  },
  progressContainer: {
    marginBottom: Spacing.lg,
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    marginBottom: Spacing.sm,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
  },
  rewardRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  rewardText: {
    fontSize: 14,
    fontWeight: "600",
  },
  milestoneItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.sm,
  },
  milestoneIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  milestoneContent: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  milestoneName: {
    fontSize: 14,
    fontWeight: "600",
  },
  milestoneReward: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 4,
  },
  milestoneBonus: {
    fontSize: 12,
    fontWeight: "600",
  },
  completedBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  completedText: {
    fontSize: 10,
    fontWeight: "600",
  },
});
