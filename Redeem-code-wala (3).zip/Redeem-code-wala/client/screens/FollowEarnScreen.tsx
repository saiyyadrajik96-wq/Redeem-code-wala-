import React from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  Linking,
} from "react-native";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors, Typography } from "@/constants/theme";

interface SocialLink {
  id: string;
  name: string;
  platform: string;
  url: string;
  icon: keyof typeof Feather.glyphMap;
  color: string;
}

const SOCIAL_LINKS: SocialLink[] = [
  {
    id: "1",
    name: "Free Fire Mr Shoeb",
    platform: "YouTube",
    url: "https://www.youtube.com/@FreeFireMrShoeb",
    icon: "video",
    color: "#FF0000",
  },
  {
    id: "2",
    name: "The Adventure Zone",
    platform: "YouTube",
    url: "https://www.youtube.com/@TheAdventureZone",
    icon: "video",
    color: "#FF0000",
  },
  {
    id: "3",
    name: "Nobita",
    platform: "Instagram",
    url: "https://www.instagram.com/its_your_shobu/",
    icon: "camera",
    color: "#E1306C",
  },
];

export default function FollowEarnScreen() {
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const handleFollow = (url: string) => {
    Linking.openURL(url);
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
          paddingHorizontal: Spacing.lg,
        }}
      >
        <View style={styles.header}>
          <ThemedText type="h4">Follow & Earn</ThemedText>
          <ThemedText style={[styles.headerSubtitle, { color: theme.textSecondary }]}>
            Follow our social media channels to earn tokens
          </ThemedText>
        </View>

        {SOCIAL_LINKS.map((link) => (
          <View
            key={link.id}
            style={[styles.card, { backgroundColor: theme.backgroundSecondary }]}
          >
            <View style={[styles.iconContainer, { backgroundColor: link.color + "20" }]}>
              <Feather name={link.icon} size={28} color={link.color} />
            </View>
            <View style={styles.cardContent}>
              <ThemedText style={styles.channelName}>{link.name}</ThemedText>
              <ThemedText style={[styles.platformName, { color: theme.textSecondary }]}>
                {link.platform}
              </ThemedText>
            </View>
            <Pressable
              style={({ pressed }) => [
                styles.followButton,
                { backgroundColor: DiamondColors.primary },
                pressed ? { opacity: 0.8, transform: [{ scale: 0.96 }] } : null,
              ]}
              onPress={() => handleFollow(link.url)}
            >
              <ThemedText style={styles.followButtonText}>Follow</ThemedText>
            </Pressable>
          </View>
        ))}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    marginBottom: Spacing.xl,
  },
  headerSubtitle: {
    fontSize: 12,
    marginTop: 4,
  },
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
  },
  iconContainer: {
    width: 52,
    height: 52,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  cardContent: {
    flex: 1,
  },
  channelName: {
    fontSize: 16,
    fontWeight: "700",
  },
  platformName: {
    fontSize: 13,
    marginTop: 2,
  },
  followButton: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  followButtonText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
});
