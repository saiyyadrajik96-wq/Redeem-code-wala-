import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Alert,
  Modal,
  RefreshControl,
  ActivityIndicator,
  Text,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import * as Clipboard from "expo-clipboard";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { RewardCard } from "@/components/RewardCard";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";
import {
  getTokens,
  spendTokens,
  addReward,
  getUser,
  TokenData,
} from "@/lib/storage";
import { getApiUrl } from "@/lib/query-client";

interface Reward {
  id: string;
  denomination: number;
  tokenCost: number;
  available: number;
}

export default function RewardsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [tokens, setTokens] = useState<TokenData>({ balance: 0, totalEarned: 0, totalSpent: 0 });
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [successModal, setSuccessModal] = useState(false);
  const [redeemedCode, setRedeemedCode] = useState("");
  const [redeemedDenom, setRedeemedDenom] = useState(0);
  const [redeeming, setRedeeming] = useState(false);

  const apiUrl = getApiUrl();

  const loadData = useCallback(async () => {
    try {
      const tokenData = await getTokens();
      setTokens(tokenData);

      const response = await fetch(new URL("/api/rewards/stock", apiUrl).toString());
      if (response.ok) {
        const stockData = await response.json();
        setRewards(stockData.map((item: any, index: number) => ({
          id: String(index + 1),
          denomination: item.denomination,
          tokenCost: item.tokenCost,
          available: item.available,
        })));
      }
    } catch (error) {
      console.error("Failed to load rewards:", error);
    } finally {
      setLoading(false);
    }
  }, [apiUrl]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleRedeem = async (reward: Reward) => {
    if (tokens.balance < reward.tokenCost) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert(
        "Insufficient Tokens",
        `You need ${reward.tokenCost.toLocaleString()} tokens to redeem this reward. You have ${tokens.balance.toLocaleString()} tokens.`,
        [{ text: "OK", style: "default" }]
      );
      return;
    }

    if (reward.available <= 0) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert(
        "Out of Stock",
        `Rs ${reward.denomination} codes are currently out of stock. Please try again later.`,
        [{ text: "OK", style: "default" }]
      );
      return;
    }

    Alert.alert(
      "Confirm Redemption",
      `Redeem Rs ${reward.denomination} Google Play code for ${reward.tokenCost.toLocaleString()} tokens?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Redeem",
          style: "default",
          onPress: async () => {
            setRedeeming(true);
            try {
              const user = await getUser();
              if (!user) {
                Alert.alert("Error", "User not found. Please restart the app.");
                setRedeeming(false);
                return;
              }

              const response = await fetch(new URL("/api/rewards/redeem", apiUrl).toString(), {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  deviceId: user.deviceId,
                  denomination: reward.denomination,
                }),
              });

              const data = await response.json();

              if (response.ok && data.success) {
                const result = await spendTokens(reward.tokenCost);
                if (result) {
                  setTokens(result);
                }

                await addReward({
                  id: Date.now().toString(),
                  denomination: data.denomination,
                  code: data.code,
                  redeemedAt: new Date().toISOString(),
                });

                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                setRedeemedCode(data.code);
                setRedeemedDenom(data.denomination);
                setSuccessModal(true);
                
                await loadData();
              } else {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
                Alert.alert("Error", data.error || "Failed to redeem code");
              }
            } catch (error) {
              console.error("Redeem error:", error);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
              Alert.alert("Error", "Failed to connect to server. Please try again.");
            } finally {
              setRedeeming(false);
            }
          },
        },
      ]
    );
  };

  const handleCopyCode = async () => {
    await Clipboard.setStringAsync(redeemedCode);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert("Copied!", "The code has been copied to your clipboard.");
  };

  const renderReward = useCallback(
    ({ item }: { item: Reward }) => (
      <View style={styles.rewardItem}>
        <RewardCard
          denomination={item.denomination}
          tokenCost={item.tokenCost}
          stock={item.available}
          onPress={() => handleRedeem(item)}
          disabled={tokens.balance < item.tokenCost || item.available <= 0}
        />
      </View>
    ),
    [tokens.balance]
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <View style={[styles.emptyIcon, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="gift" size={48} color={theme.gold} />
      </View>
      <ThemedText type="h4" style={styles.emptyTitle}>
        No Rewards Available
      </ThemedText>
      <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
        Admin needs to add redeem codes. Check back later!
      </ThemedText>
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <LinearGradient
        colors={["rgba(255, 215, 0, 0.15)", "rgba(10, 132, 255, 0.08)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.balanceCard}
      >
        <ThemedText style={[styles.balanceLabel, { color: theme.textSecondary }]}>
          Available Balance
        </ThemedText>
        <View style={styles.balanceRow}>
          <Feather name="hexagon" size={24} color={theme.gold} />
          <ThemedText style={[styles.balance, { color: theme.text }]}>
            {tokens.balance.toLocaleString()}
          </ThemedText>
        </View>
      </LinearGradient>

      <View style={styles.infoRow}>
        <Feather name="info" size={14} color={theme.textSecondary} />
        <ThemedText style={[styles.infoText, { color: theme.textSecondary }]}>
          Redeem your tokens for real Google Play codes
        </ThemedText>
      </View>

      <View style={[styles.stockNotice, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="package" size={16} color={DiamondColors.primary} />
        <Text style={[styles.stockText, { color: theme.text }]}>
          Live stock from admin inventory
        </Text>
      </View>
    </View>
  );

  if (loading) {
    return (
      <ThemedView style={[styles.container, styles.loadingContainer]}>
        <ActivityIndicator size="large" color={DiamondColors.primary} />
        <Text style={[styles.loadingText, { color: theme.textSecondary }]}>
          Loading rewards...
        </Text>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      {redeeming && (
        <View style={styles.redeemingOverlay}>
          <ActivityIndicator size="large" color={DiamondColors.gold} />
          <Text style={styles.redeemingText}>Redeeming...</Text>
        </View>
      )}
      
      <FlatList
        data={rewards}
        renderItem={renderReward}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={theme.primary}
          />
        }
      />

      <Modal
        visible={successModal}
        animationType="fade"
        transparent
        onRequestClose={() => setSuccessModal(false)}
      >
        <View style={styles.modalOverlay}>
          <LinearGradient
            colors={[theme.backgroundDefault, theme.backgroundSecondary]}
            style={styles.successModal}
          >
            <View style={[styles.successIcon, { backgroundColor: theme.success + "20" }]}>
              <Feather name="check-circle" size={48} color={theme.success} />
            </View>

            <ThemedText type="h3" style={styles.successTitle}>
              Congratulations!
            </ThemedText>
            <ThemedText style={[styles.successText, { color: theme.textSecondary }]}>
              You have successfully redeemed a Rs {redeemedDenom} Google Play code
            </ThemedText>

            <View style={[styles.codeContainer, { backgroundColor: theme.backgroundRoot }]}>
              <ThemedText style={styles.codeLabel}>Your Code</ThemedText>
              <ThemedText style={[styles.codeText, { color: theme.gold }]}>
                {redeemedCode}
              </ThemedText>
            </View>

            <View style={styles.modalButtons}>
              <Button onPress={handleCopyCode} style={styles.copyButton}>
                Copy Code
              </Button>
              <Button
                onPress={() => setSuccessModal(false)}
                style={[styles.doneButton, { backgroundColor: theme.backgroundTertiary }]}
              >
                Done
              </Button>
            </View>
          </LinearGradient>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: Spacing.md,
    fontSize: 14,
  },
  redeemingOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 100,
  },
  redeemingText: {
    color: "#fff",
    marginTop: Spacing.md,
    fontSize: 16,
    fontWeight: "600",
  },
  header: {
    marginBottom: Spacing.xl,
  },
  balanceCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: "rgba(255, 215, 0, 0.2)",
    alignItems: "center",
  },
  balanceLabel: {
    fontSize: 14,
    marginBottom: Spacing.sm,
  },
  balanceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  balance: {
    fontSize: 32,
    fontWeight: "800",
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginTop: Spacing.lg,
    justifyContent: "center",
  },
  infoText: {
    fontSize: 12,
  },
  stockNotice: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    marginTop: Spacing.md,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.sm,
  },
  stockText: {
    fontSize: 12,
    fontWeight: "500",
  },
  row: {
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  rewardItem: {
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xl,
  },
  emptyTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  emptyText: {
    textAlign: "center",
    fontSize: 14,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.8)",
    alignItems: "center",
    justifyContent: "center",
    padding: Spacing.xl,
  },
  successModal: {
    width: "100%",
    maxWidth: 340,
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    alignItems: "center",
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xl,
  },
  successTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  successText: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  codeContainer: {
    width: "100%",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  codeLabel: {
    fontSize: 12,
    marginBottom: Spacing.sm,
  },
  codeText: {
    fontSize: 18,
    fontWeight: "700",
    letterSpacing: 1,
  },
  modalButtons: {
    width: "100%",
    gap: Spacing.sm,
  },
  copyButton: {
    width: "100%",
  },
  doneButton: {
    width: "100%",
  },
});
