import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Dimensions,
  Platform,
} from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withSequence,
  withDelay,
  runOnJS,
  Easing,
  FadeIn,
  FadeOut,
} from "react-native-reanimated";
import { Feather } from "@expo/vector-icons";
import { DiamondColors, Colors, Spacing, BorderRadius, Typography } from "@/constants/theme";
import { initializeUser, setLoginState } from "@/lib/storage";

const { width, height } = Dimensions.get("window");

interface LoginScreenProps {
  onLoginComplete: () => void;
}

export default function LoginScreen({ onLoginComplete }: LoginScreenProps) {
  const insets = useSafeAreaInsets();
  const theme = Colors.dark;
  const [isLoading, setIsLoading] = useState(false);
  const [showAnimation, setShowAnimation] = useState(false);

  const logoScale = useSharedValue(0);
  const logoOpacity = useSharedValue(0);
  const titleOpacity = useSharedValue(0);
  const titleTranslateY = useSharedValue(30);
  const buttonOpacity = useSharedValue(0);
  const buttonTranslateY = useSharedValue(30);
  
  const animationScale = useSharedValue(0);
  const animationOpacity = useSharedValue(0);
  const checkScale = useSharedValue(0);
  const welcomeOpacity = useSharedValue(0);
  const welcomeScale = useSharedValue(0.5);

  useEffect(() => {
    logoScale.value = withSpring(1, { damping: 12 });
    logoOpacity.value = withTiming(1, { duration: 600 });
    
    titleOpacity.value = withDelay(300, withTiming(1, { duration: 500 }));
    titleTranslateY.value = withDelay(300, withSpring(0, { damping: 15 }));
    
    buttonOpacity.value = withDelay(600, withTiming(1, { duration: 500 }));
    buttonTranslateY.value = withDelay(600, withSpring(0, { damping: 15 }));
  }, []);

  const logoAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: logoScale.value }],
    opacity: logoOpacity.value,
  }));

  const titleAnimatedStyle = useAnimatedStyle(() => ({
    opacity: titleOpacity.value,
    transform: [{ translateY: titleTranslateY.value }],
  }));

  const buttonAnimatedStyle = useAnimatedStyle(() => ({
    opacity: buttonOpacity.value,
    transform: [{ translateY: buttonTranslateY.value }],
  }));

  const animationContainerStyle = useAnimatedStyle(() => ({
    opacity: animationOpacity.value,
    transform: [{ scale: animationScale.value }],
  }));

  const checkAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: checkScale.value }],
  }));

  const welcomeAnimatedStyle = useAnimatedStyle(() => ({
    opacity: welcomeOpacity.value,
    transform: [{ scale: welcomeScale.value }],
  }));

  const playSuccessAnimation = () => {
    setShowAnimation(true);
    
    animationOpacity.value = withTiming(1, { duration: 300 });
    animationScale.value = withSpring(1, { damping: 12 });
    
    checkScale.value = withDelay(300, withSequence(
      withSpring(1.3, { damping: 8 }),
      withSpring(1, { damping: 12 })
    ));
    
    welcomeOpacity.value = withDelay(600, withTiming(1, { duration: 400 }));
    welcomeScale.value = withDelay(600, withSpring(1, { damping: 12 }));
    
    setTimeout(() => {
      onLoginComplete();
    }, 2000);
  };

  const handleGoogleLogin = async () => {
    if (isLoading) return;
    
    setIsLoading(true);
    
    try {
      await initializeUser();
      await setLoginState(true);
      playSuccessAnimation();
    } catch (error) {
      console.error("Login error:", error);
      setIsLoading(false);
    }
  };

  if (showAnimation) {
    return (
      <LinearGradient
        colors={[theme.backgroundRoot, theme.backgroundDefault, theme.backgroundRoot]}
        style={styles.container}
      >
        <Animated.View style={[styles.animationContainer, animationContainerStyle]}>
          <Animated.View style={[styles.checkCircle, checkAnimatedStyle]}>
            <LinearGradient
              colors={[DiamondColors.primary, DiamondColors.primaryDark]}
              style={styles.checkGradient}
            >
              <Feather name="check" size={60} color="#fff" />
            </LinearGradient>
          </Animated.View>
          
          <Animated.View style={welcomeAnimatedStyle}>
            <Text style={[styles.welcomeText, { color: theme.text }]}>
              Welcome to
            </Text>
            <Text style={[styles.appNameText, { color: DiamondColors.gold }]}>
              REDEEM CODE WALA
            </Text>
            <Text style={[styles.subtitleText, { color: theme.textSecondary }]}>
              Earn tokens, redeem rewards!
            </Text>
          </Animated.View>
        </Animated.View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient
      colors={[theme.backgroundRoot, theme.backgroundDefault, theme.backgroundRoot]}
      style={styles.container}
    >
      <View style={[styles.content, { paddingTop: insets.top + Spacing["4xl"] }]}>
        <Animated.View style={[styles.logoContainer, logoAnimatedStyle]}>
          <View style={styles.logoGlow}>
            <Image
              source={require("../../assets/images/icon.png")}
              style={styles.logo}
              contentFit="contain"
            />
          </View>
        </Animated.View>

        <Animated.View style={[styles.titleContainer, titleAnimatedStyle]}>
          <Text style={[styles.appTitle, { color: DiamondColors.gold }]}>
            REDEEM CODE WALA
          </Text>
          <Text style={[styles.tagline, { color: theme.textSecondary }]}>
            Play games, earn tokens, get rewards!
          </Text>
        </Animated.View>

        <Animated.View style={[styles.buttonContainer, buttonAnimatedStyle]}>
          <Pressable
            style={({ pressed }) => [
              styles.authButton,
              pressed && styles.buttonPressed,
            ]}
            onPress={handleGoogleLogin}
            disabled={isLoading}
          >
            <LinearGradient
              colors={[DiamondColors.gold, DiamondColors.goldDark]}
              style={styles.authButtonGradient}
            >
              <Text style={styles.signUpButtonText}>
                {isLoading ? "Please wait..." : "Sign Up"}
              </Text>
            </LinearGradient>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.authButton,
              pressed && styles.buttonPressed,
            ]}
            onPress={handleGoogleLogin}
            disabled={isLoading}
          >
            <LinearGradient
              colors={[DiamondColors.primary, DiamondColors.primaryDark]}
              style={styles.authButtonGradient}
            >
              <Text style={styles.loginButtonText}>
                {isLoading ? "Please wait..." : "Login"}
              </Text>
            </LinearGradient>
          </Pressable>

          <Text style={[styles.termsText, { color: theme.textSecondary }]}>
            By continuing, you agree to our Terms of Service and Privacy Policy
          </Text>
        </Animated.View>

        <View style={styles.featuresContainer}>
          <View style={styles.featureRow}>
            <View style={[styles.featureIcon, { backgroundColor: DiamondColors.primary + "20" }]}>
              <Feather name="gift" size={20} color={DiamondColors.primary} />
            </View>
            <Text style={[styles.featureText, { color: theme.text }]}>
              Earn free Google Play codes
            </Text>
          </View>
          <View style={styles.featureRow}>
            <View style={[styles.featureIcon, { backgroundColor: DiamondColors.gold + "20" }]}>
              <Feather name="play-circle" size={20} color={DiamondColors.gold} />
            </View>
            <Text style={[styles.featureText, { color: theme.text }]}>
              Play fun games for tokens
            </Text>
          </View>
          <View style={styles.featureRow}>
            <View style={[styles.featureIcon, { backgroundColor: DiamondColors.success + "20" }]}>
              <Feather name="shield" size={20} color={DiamondColors.success} />
            </View>
            <Text style={[styles.featureText, { color: theme.text }]}>
              Safe & secure rewards
            </Text>
          </View>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
  },
  logoContainer: {
    marginBottom: Spacing["3xl"],
  },
  logoGlow: {
    shadowColor: DiamondColors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 30,
    elevation: 20,
  },
  logo: {
    width: 140,
    height: 140,
    borderRadius: BorderRadius.xl,
  },
  titleContainer: {
    alignItems: "center",
    marginBottom: Spacing["4xl"],
  },
  appTitle: {
    ...Typography.h1,
    fontSize: 28,
    fontWeight: "800",
    letterSpacing: 1,
    textAlign: "center",
  },
  tagline: {
    ...Typography.body,
    marginTop: Spacing.sm,
    textAlign: "center",
  },
  buttonContainer: {
    width: "100%",
    alignItems: "center",
    marginBottom: Spacing["4xl"],
  },
  authButton: {
    width: "100%",
    maxWidth: 320,
    borderRadius: BorderRadius.md,
    overflow: "hidden",
    marginBottom: Spacing.md,
  },
  authButtonGradient: {
    paddingVertical: Spacing.lg,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: BorderRadius.md,
  },
  signUpButtonText: {
    color: "#000",
    fontSize: 16,
    fontWeight: "700",
  },
  loginButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  buttonPressed: {
    transform: [{ scale: 0.98 }],
    opacity: 0.9,
  },
  termsText: {
    ...Typography.small,
    fontSize: 12,
    textAlign: "center",
    marginTop: Spacing.lg,
    paddingHorizontal: Spacing.xl,
  },
  featuresContainer: {
    marginTop: "auto",
    marginBottom: Spacing["4xl"],
    width: "100%",
  },
  featureRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  featureIcon: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  featureText: {
    ...Typography.body,
    flex: 1,
  },
  animationContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  checkCircle: {
    marginBottom: Spacing["3xl"],
  },
  checkGradient: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: DiamondColors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 15,
  },
  welcomeText: {
    ...Typography.h3,
    textAlign: "center",
    marginBottom: Spacing.xs,
  },
  appNameText: {
    ...Typography.h1,
    fontSize: 26,
    fontWeight: "800",
    textAlign: "center",
    letterSpacing: 1,
  },
  subtitleText: {
    ...Typography.body,
    textAlign: "center",
    marginTop: Spacing.sm,
  },
});
