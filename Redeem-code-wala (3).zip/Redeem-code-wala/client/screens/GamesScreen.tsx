import React, { useState, useCallback, useRef, useEffect } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Modal,
  Alert,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { WebView } from "react-native-webview";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { GameCard } from "@/components/GameCard";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";
import { addTokens, addGameSession, getTokens, TokenData } from "@/lib/storage";

interface Game {
  id: string;
  name: string;
  category: string;
  tokensPerMin: number;
  iconName: keyof typeof Feather.glyphMap;
  color: string;
  url: string;
}

const GAMES: Game[] = [
  {
    id: "1",
    name: "Ludo",
    category: "Board",
    tokensPerMin: 3,
    iconName: "disc",
    color: "#FF6B6B",
    url: "https://www.playok.com/en/ludo/",
  },
  {
    id: "2",
    name: "Carrom",
    category: "Board",
    tokensPerMin: 2,
    iconName: "circle",
    color: "#D4A574",
    url: "https://www.gameflare.com/online-game/carrom-pool/",
  },
  {
    id: "3",
    name: "Chess",
    category: "Strategy",
    tokensPerMin: 4,
    iconName: "target",
    color: "#9B59B6",
    url: "https://www.chess.com/play/computer",
  },
  {
    id: "4",
    name: "Tic Tac Toe",
    category: "Puzzle",
    tokensPerMin: 1,
    iconName: "hash",
    color: "#4ECDC4",
    url: "https://playtictactoe.org/",
  },
  {
    id: "5",
    name: "2048",
    category: "Puzzle",
    tokensPerMin: 2,
    iconName: "grid",
    color: "#FF9F43",
    url: "https://play2048.co/",
  },
  {
    id: "6",
    name: "Snake",
    category: "Arcade",
    tokensPerMin: 1,
    iconName: "activity",
    color: "#26DE81",
    url: "https://playsnake.org/",
  },
];

export default function GamesScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [gameModalVisible, setGameModalVisible] = useState(false);
  const [playTime, setPlayTime] = useState(0);
  const [tokens, setTokens] = useState<TokenData>({ balance: 0, totalEarned: 0, totalSpent: 0 });
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    loadTokens();
  }, []);

  const loadTokens = async () => {
    const tokenData = await getTokens();
    setTokens(tokenData);
  };

  const handleGamePress = (game: Game) => {
    setSelectedGame(game);
    setPlayTime(0);
    setGameModalVisible(true);

    timerRef.current = setInterval(() => {
      setPlayTime((prev) => prev + 1);
    }, 1000);
  };

  const handleCloseGame = async () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (selectedGame && playTime >= 180) {
      const minutes = Math.floor(playTime / 60);
      const tokensEarned = minutes * selectedGame.tokensPerMin;

      await addGameSession({
        gameId: selectedGame.id,
        gameName: selectedGame.name,
        playTime,
        tokensEarned,
        playedAt: new Date().toISOString(),
      });

      await addTokens(tokensEarned);
      const newTokens = await getTokens();
      setTokens(newTokens);

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      Alert.alert(
        "Tokens Earned!",
        `You played for ${minutes} minute${minutes > 1 ? "s" : ""} and earned ${tokensEarned} tokens!`,
        [{ text: "Awesome!", style: "default" }]
      );
    } else if (selectedGame && playTime < 180) {
      Alert.alert(
        "Keep Playing!",
        "Play for at least 3 minutes to earn tokens.",
        [{ text: "OK", style: "default" }]
      );
    }

    setGameModalVisible(false);
    setSelectedGame(null);
    setPlayTime(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const renderGame = useCallback(
    ({ item }: { item: Game }) => (
      <View style={styles.gameItem}>
        <GameCard
          name={item.name}
          category={item.category}
          tokensPerMin={item.tokensPerMin}
          iconName={item.iconName}
          color={item.color}
          onPress={() => handleGamePress(item)}
        />
      </View>
    ),
    []
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <View style={[styles.emptyIcon, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="play-circle" size={48} color={theme.primary} />
      </View>
      <ThemedText type="h4" style={styles.emptyTitle}>
        Game Arena
      </ThemedText>
      <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
        Play games and earn tokens! More games coming soon.
      </ThemedText>
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <View style={styles.headerContent}>
        <ThemedText type="h4">Play & Earn</ThemedText>
        <ThemedText style={[styles.headerSubtitle, { color: theme.textSecondary }]}>
          Play for at least 3 minutes to earn tokens
        </ThemedText>
      </View>
      <View style={[styles.tokenBadge, { backgroundColor: theme.gold + "20" }]}>
        <Feather name="hexagon" size={14} color={theme.gold} />
        <ThemedText style={[styles.tokenText, { color: theme.gold }]}>
          {tokens.balance.toLocaleString()}
        </ThemedText>
      </View>
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <FlatList
        data={GAMES}
        renderItem={renderGame}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
      />

      <Modal
        visible={gameModalVisible}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={handleCloseGame}
      >
        <View style={[styles.gameModal, { backgroundColor: theme.backgroundRoot }]}>
          <View
            style={[
              styles.gameHeader,
              { backgroundColor: theme.backgroundDefault, paddingTop: insets.top },
            ]}
          >
            <View style={styles.gameInfo}>
              <ThemedText style={styles.gameName}>{selectedGame?.name}</ThemedText>
              <View style={styles.timerContainer}>
                <Feather name="clock" size={14} color={theme.textSecondary} />
                <ThemedText style={[styles.timerText, { color: theme.textSecondary }]}>
                  {formatTime(playTime)}
                </ThemedText>
              </View>
            </View>
            <View style={styles.gameStats}>
              <View style={[styles.earnBadge, { backgroundColor: theme.gold + "20" }]}>
                <Feather name="hexagon" size={12} color={theme.gold} />
                <ThemedText style={[styles.earnText, { color: theme.gold }]}>
                  +{Math.floor(playTime / 60) * (selectedGame?.tokensPerMin || 0)}
                </ThemedText>
              </View>
              <Button onPress={handleCloseGame} style={styles.closeButton}>
                Exit Game
              </Button>
            </View>
          </View>

          {Platform.OS === "web" ? (
            <View style={styles.webFallback}>
              <Feather name="monitor" size={48} color={theme.textSecondary} />
              <ThemedText style={[styles.webText, { color: theme.textSecondary }]}>
                Open in Expo Go on your phone to play games
              </ThemedText>
            </View>
          ) : selectedGame ? (
            <WebView
              source={{ uri: selectedGame.url }}
              style={styles.webview}
              javaScriptEnabled
              domStorageEnabled
              startInLoadingState
            />
          ) : null}
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: Spacing.xl,
  },
  headerContent: {
    flex: 1,
  },
  headerSubtitle: {
    fontSize: 12,
    marginTop: 4,
  },
  tokenBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  tokenText: {
    fontSize: 14,
    fontWeight: "700",
  },
  row: {
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  gameItem: {
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xl,
  },
  emptyTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  emptyText: {
    textAlign: "center",
    fontSize: 14,
  },
  gameModal: {
    flex: 1,
  },
  gameHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  gameInfo: {
    flex: 1,
  },
  gameName: {
    fontSize: 18,
    fontWeight: "700",
  },
  timerContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 4,
  },
  timerText: {
    fontSize: 14,
  },
  gameStats: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  earnBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  earnText: {
    fontSize: 12,
    fontWeight: "700",
  },
  closeButton: {
    paddingHorizontal: Spacing.lg,
    height: 40,
  },
  webview: {
    flex: 1,
  },
  webFallback: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.lg,
    paddingHorizontal: Spacing.xl,
  },
  webText: {
    textAlign: "center",
    fontSize: 16,
  },
});
