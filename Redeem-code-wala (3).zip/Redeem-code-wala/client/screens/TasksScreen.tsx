import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Linking,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/hooks/useTheme";
import { DiamondColors, Spacing, BorderRadius, Typography } from "@/constants/theme";
import { addTokens } from "@/lib/storage";

interface TaskOffer {
  id: string;
  name: string;
  description: string;
  tokens: number;
  icon: keyof typeof Feather.glyphMap;
  color: string;
  url: string;
  type: "survey" | "app" | "video" | "offer";
}

const TASK_OFFERS: TaskOffer[] = [
  {
    id: "1",
    name: "Google Opinion Rewards",
    description: "Complete surveys to earn tokens",
    tokens: 50,
    icon: "file-text",
    color: "#4285F4",
    url: "https://play.google.com/store/apps/details?id=com.google.android.apps.paidtasks",
    type: "survey",
  },
  {
    id: "2",
    name: "Swagbucks",
    description: "Watch videos & complete offers",
    tokens: 100,
    icon: "tv",
    color: "#00A2E8",
    url: "https://www.swagbucks.com/",
    type: "video",
  },
  {
    id: "3",
    name: "Poll Pay",
    description: "Take surveys and earn rewards",
    tokens: 75,
    icon: "bar-chart-2",
    color: "#6C5CE7",
    url: "https://www.pollpay.app/",
    type: "survey",
  },
  {
    id: "4",
    name: "FeaturePoints",
    description: "Download apps & earn points",
    tokens: 80,
    icon: "download",
    color: "#00C853",
    url: "https://featu.re/",
    type: "app",
  },
  {
    id: "5",
    name: "Mistplay",
    description: "Play games & earn rewards",
    tokens: 60,
    icon: "play",
    color: "#FF6B6B",
    url: "https://www.mistplay.com/",
    type: "app",
  },
  {
    id: "6",
    name: "Survey Junkie",
    description: "Share opinions for cash",
    tokens: 90,
    icon: "check-circle",
    color: "#7C4DFF",
    url: "https://www.surveyjunkie.com/",
    type: "survey",
  },
  {
    id: "7",
    name: "InboxDollars",
    description: "Earn cash for online activities",
    tokens: 70,
    icon: "inbox",
    color: "#FF9500",
    url: "https://www.inboxdollars.com/",
    type: "offer",
  },
  {
    id: "8",
    name: "Branded Surveys",
    description: "Get paid for your opinions",
    tokens: 85,
    icon: "award",
    color: "#1ABC9C",
    url: "https://surveys.gobranded.com/",
    type: "survey",
  },
];

export default function TasksScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());

  const handleOpenTask = async (task: TaskOffer) => {
    try {
      await Linking.openURL(task.url);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } catch (error) {
      Alert.alert("Error", "Could not open link");
    }
  };

  const handleClaimReward = async (task: TaskOffer) => {
    if (completedTasks.has(task.id)) {
      Alert.alert("Already Claimed", "You have already claimed this reward.");
      return;
    }

    Alert.alert(
      "Claim Reward",
      `Did you complete the task on ${task.name}? You will receive ${task.tokens} tokens.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Claim",
          onPress: async () => {
            await addTokens(task.tokens);
            setCompletedTasks((prev) => new Set(prev).add(task.id));
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            Alert.alert("Success!", `You earned ${task.tokens} tokens!`);
          },
        },
      ]
    );
  };

  const getTypeLabel = (type: TaskOffer["type"]) => {
    switch (type) {
      case "survey":
        return "Survey";
      case "app":
        return "App";
      case "video":
        return "Video";
      case "offer":
        return "Offer";
    }
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
    >
      <LinearGradient
        colors={[DiamondColors.primary + "20", DiamondColors.gold + "10"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.headerCard}
      >
        <View style={styles.headerIcon}>
          <Feather name="briefcase" size={32} color={DiamondColors.gold} />
        </View>
        <Text style={[styles.headerTitle, { color: theme.text }]}>
          Complete Tasks & Earn
        </Text>
        <Text style={[styles.headerSubtitle, { color: theme.textSecondary }]}>
          Complete tasks on partner websites to earn tokens
        </Text>
      </LinearGradient>

      <View style={styles.infoCard}>
        <View style={[styles.infoItem, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="external-link" size={20} color={DiamondColors.primary} />
          <Text style={[styles.infoText, { color: theme.textSecondary }]}>
            Tap to open website
          </Text>
        </View>
        <View style={[styles.infoItem, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="check" size={20} color={DiamondColors.success} />
          <Text style={[styles.infoText, { color: theme.textSecondary }]}>
            Complete the task
          </Text>
        </View>
        <View style={[styles.infoItem, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="gift" size={20} color={DiamondColors.gold} />
          <Text style={[styles.infoText, { color: theme.textSecondary }]}>
            Claim your tokens
          </Text>
        </View>
      </View>

      <Text style={[styles.sectionTitle, { color: theme.text }]}>
        Available Tasks ({TASK_OFFERS.length})
      </Text>

      {TASK_OFFERS.map((task) => {
        const isCompleted = completedTasks.has(task.id);
        return (
          <View
            key={task.id}
            style={[
              styles.taskCard,
              { backgroundColor: theme.backgroundSecondary },
              isCompleted && styles.taskCompleted,
            ]}
          >
            <View style={styles.taskHeader}>
              <View style={[styles.taskIcon, { backgroundColor: task.color + "20" }]}>
                <Feather name={task.icon} size={24} color={task.color} />
              </View>
              <View style={styles.taskInfo}>
                <Text style={[styles.taskName, { color: theme.text }]}>{task.name}</Text>
                <Text style={[styles.taskDesc, { color: theme.textSecondary }]}>
                  {task.description}
                </Text>
              </View>
              <View style={[styles.typeBadge, { backgroundColor: task.color + "20" }]}>
                <Text style={[styles.typeText, { color: task.color }]}>
                  {getTypeLabel(task.type)}
                </Text>
              </View>
            </View>

            <View style={styles.taskFooter}>
              <View style={styles.tokenReward}>
                <Feather name="star" size={16} color={DiamondColors.gold} />
                <Text style={[styles.tokenAmount, { color: DiamondColors.gold }]}>
                  +{task.tokens} Tokens
                </Text>
              </View>

              <View style={styles.taskButtons}>
                <Pressable
                  style={({ pressed }) => [
                    styles.openButton,
                    { backgroundColor: theme.backgroundTertiary },
                    pressed && styles.buttonPressed,
                  ]}
                  onPress={() => handleOpenTask(task)}
                >
                  <Feather name="external-link" size={16} color={theme.text} />
                  <Text style={[styles.openButtonText, { color: theme.text }]}>Open</Text>
                </Pressable>

                <Pressable
                  style={({ pressed }) => [
                    styles.claimButton,
                    isCompleted && styles.claimedButton,
                    pressed && !isCompleted && styles.buttonPressed,
                  ]}
                  onPress={() => handleClaimReward(task)}
                  disabled={isCompleted}
                >
                  <LinearGradient
                    colors={
                      isCompleted
                        ? [theme.backgroundTertiary, theme.backgroundTertiary]
                        : [DiamondColors.success, "#28A745"]
                    }
                    style={styles.claimGradient}
                  >
                    <Feather
                      name={isCompleted ? "check" : "gift"}
                      size={16}
                      color={isCompleted ? theme.textSecondary : "#fff"}
                    />
                    <Text
                      style={[
                        styles.claimButtonText,
                        { color: isCompleted ? theme.textSecondary : "#fff" },
                      ]}
                    >
                      {isCompleted ? "Claimed" : "Claim"}
                    </Text>
                  </LinearGradient>
                </Pressable>
              </View>
            </View>
          </View>
        );
      })}

      <View style={[styles.disclaimerCard, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="info" size={16} color={theme.textSecondary} />
        <Text style={[styles.disclaimerText, { color: theme.textSecondary }]}>
          Tasks are provided by third-party partners. Complete tasks honestly to receive
          rewards. Fraudulent activity may result in account suspension.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  headerIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "rgba(255, 215, 0, 0.15)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  headerTitle: {
    ...Typography.h3,
    textAlign: "center",
    marginBottom: Spacing.xs,
  },
  headerSubtitle: {
    ...Typography.body,
    textAlign: "center",
  },
  infoCard: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  infoItem: {
    flex: 1,
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    gap: Spacing.xs,
  },
  infoText: {
    fontSize: 10,
    textAlign: "center",
  },
  sectionTitle: {
    ...Typography.h4,
    marginBottom: Spacing.md,
  },
  taskCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
  },
  taskCompleted: {
    opacity: 0.7,
  },
  taskHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  taskIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  taskInfo: {
    flex: 1,
  },
  taskName: {
    ...Typography.body,
    fontWeight: "600",
  },
  taskDesc: {
    ...Typography.small,
    marginTop: 2,
  },
  typeBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  typeText: {
    fontSize: 10,
    fontWeight: "600",
  },
  taskFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tokenReward: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  tokenAmount: {
    fontWeight: "700",
    fontSize: 14,
  },
  taskButtons: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  openButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.xs,
  },
  openButtonText: {
    fontSize: 12,
    fontWeight: "600",
  },
  claimButton: {
    borderRadius: BorderRadius.xs,
    overflow: "hidden",
  },
  claimedButton: {
    opacity: 0.6,
  },
  claimGradient: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  claimButtonText: {
    fontSize: 12,
    fontWeight: "600",
  },
  buttonPressed: {
    opacity: 0.8,
    transform: [{ scale: 0.98 }],
  },
  disclaimerCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: Spacing.sm,
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.md,
  },
  disclaimerText: {
    flex: 1,
    fontSize: 11,
    lineHeight: 16,
  },
});
