import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useTheme } from "@/hooks/useTheme";
import { DiamondColors, Spacing, BorderRadius, Typography } from "@/constants/theme";
import { getApiUrl } from "@/lib/query-client";

interface RedeemCode {
  id: string;
  code: string;
  denomination: number;
  isRedeemed: boolean;
  redeemedBy: string | null;
  createdAt: string;
}

interface CodeStats {
  denomination: number;
  available: number;
  redeemed: number;
}

interface BlockedUser {
  id: string;
  uid: string;
  reason: string | null;
  blockedAt: string;
}

interface AppUser {
  id: string;
  deviceId: string;
  referralCode: string;
  referredBy: string | null;
  tokenBalance: number;
  totalEarned: number;
  totalSpent: number;
  createdAt: string;
}

type AdminTab = "codes" | "users" | "blocked";

export default function AdminScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [adminId, setAdminId] = useState("");
  
  const [activeTab, setActiveTab] = useState<AdminTab>("codes");
  const [codes, setCodes] = useState<RedeemCode[]>([]);
  const [stats, setStats] = useState<CodeStats[]>([]);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [allUsers, setAllUsers] = useState<AppUser[]>([]);
  const [newCode, setNewCode] = useState("");
  const [newDenom, setNewDenom] = useState("10");
  const [blockUid, setBlockUid] = useState("");
  const [blockReason, setBlockReason] = useState("");
  const [blockType, setBlockType] = useState("misbehave");
  const [sendTokenUid, setSendTokenUid] = useState("");
  const [sendTokenAmount, setSendTokenAmount] = useState("");
  
  const apiUrl = getApiUrl();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter email and password");
      return;
    }
    
    setIsLoading(true);
    try {
      const response = await fetch(new URL("/api/admin/login", apiUrl).toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setAdminId(data.admin.id);
        setIsLoggedIn(true);
        fetchData();
      } else {
        Alert.alert("Error", data.error || "Login failed");
      }
    } catch (error) {
      Alert.alert("Error", "Connection failed");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchData = async () => {
    try {
      const [codesRes, statsRes, blockedRes, usersRes] = await Promise.all([
        fetch(new URL("/api/admin/codes", apiUrl).toString()),
        fetch(new URL("/api/admin/stats", apiUrl).toString()),
        fetch(new URL("/api/admin/blocked", apiUrl).toString()),
        fetch(new URL("/api/admin/users", apiUrl).toString()),
      ]);
      
      const codesData = await codesRes.json();
      const statsData = await statsRes.json();
      const blockedData = await blockedRes.json();
      const usersData = await usersRes.json();
      
      setCodes(codesData);
      setStats(statsData);
      setBlockedUsers(blockedData);
      setAllUsers(usersData);
    } catch (error) {
      console.error("Fetch error:", error);
    }
  };

  const handleAddCode = async () => {
    if (!newCode.trim()) {
      Alert.alert("Error", "Please enter a code");
      return;
    }
    
    setIsLoading(true);
    try {
      const response = await fetch(new URL("/api/admin/codes", apiUrl).toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: newCode.trim(),
          denomination: parseInt(newDenom),
          adminId,
        }),
      });
      
      if (response.ok) {
        setNewCode("");
        fetchData();
        Alert.alert("Success", `Rs.${newDenom} code added successfully`);
      } else {
        const data = await response.json();
        Alert.alert("Error", data.error || "Failed to add code");
      }
    } catch (error) {
      Alert.alert("Error", "Failed to add code");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteCode = async (codeId: string) => {
    Alert.alert("Delete Code", "Are you sure you want to delete this code?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            const response = await fetch(
              new URL(`/api/admin/codes/${codeId}`, apiUrl).toString(),
              { method: "DELETE" }
            );
            
            if (response.ok) {
              fetchData();
            } else {
              Alert.alert("Error", "Failed to delete code");
            }
          } catch (error) {
            Alert.alert("Error", "Failed to delete code");
          }
        },
      },
    ]);
  };

  const handleBlockUser = async () => {
    if (!blockUid.trim()) {
      Alert.alert("Error", "Please enter a UID to block");
      return;
    }
    
    setIsLoading(true);
    try {
      const response = await fetch(new URL("/api/admin/block", apiUrl).toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          uid: blockUid.trim().toUpperCase(),
          reason: blockReason.trim() || "Blocked by admin",
          adminId,
          blockType,
        }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setBlockUid("");
        setBlockReason("");
        fetchData();
        Alert.alert("Success", "User blocked successfully");
      } else {
        Alert.alert("Error", data.error || "Failed to block user");
      }
    } catch (error) {
      Alert.alert("Error", "Failed to block user");
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnblockUser = async (uid: string) => {
    Alert.alert("Unblock User", `Are you sure you want to unblock ${uid}?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Unblock",
        onPress: async () => {
          try {
            const response = await fetch(new URL("/api/admin/unblock", apiUrl).toString(), {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ uid }),
            });
            
            if (response.ok) {
              fetchData();
              Alert.alert("Success", "User unblocked");
            } else {
              Alert.alert("Error", "Failed to unblock user");
            }
          } catch (error) {
            Alert.alert("Error", "Failed to unblock user");
          }
        },
      },
    ]);
  };

  if (!isLoggedIn) {
    return (
      <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
        <View style={[styles.content, { paddingTop: headerHeight + Spacing.xl }]}>
          <View style={styles.loginCard}>
            <LinearGradient
              colors={[theme.backgroundSecondary, theme.backgroundTertiary]}
              style={styles.cardGradient}
            >
              <Feather name="shield" size={48} color={DiamondColors.gold} style={styles.icon} />
              <Text style={[styles.title, { color: theme.text }]}>Admin Login</Text>
              
              <TextInput
                style={[styles.input, { color: theme.text, backgroundColor: theme.backgroundRoot }]}
                placeholder="Admin Email"
                placeholderTextColor={theme.textSecondary}
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
              />
              
              <TextInput
                style={[styles.input, { color: theme.text, backgroundColor: theme.backgroundRoot }]}
                placeholder="Password"
                placeholderTextColor={theme.textSecondary}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
              />
              
              <Pressable
                style={({ pressed }) => [
                  styles.loginButton,
                  pressed && styles.buttonPressed,
                ]}
                onPress={handleLogin}
                disabled={isLoading}
              >
                <LinearGradient
                  colors={[DiamondColors.gold, DiamondColors.goldDark]}
                  style={styles.buttonGradient}
                >
                  {isLoading ? (
                    <ActivityIndicator color="#000" />
                  ) : (
                    <Text style={styles.buttonText}>Login</Text>
                  )}
                </LinearGradient>
              </Pressable>
            </LinearGradient>
          </View>
        </View>
      </View>
    );
  }

  const renderCodesTab = () => (
    <>
      <View style={styles.statsContainer}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Stock Overview</Text>
        <View style={styles.statsGrid}>
          {[10, 50, 100, 500].map((denom) => {
            const stat = stats.find((s) => s.denomination === denom);
            return (
              <View
                key={denom}
                style={[styles.statCard, { backgroundColor: theme.backgroundSecondary }]}
              >
                <Text style={[styles.statDenom, { color: DiamondColors.gold }]}>
                  Rs.{denom}
                </Text>
                <Text style={[styles.statValue, { color: theme.text }]}>
                  {stat?.available || 0}
                </Text>
                <Text style={[styles.statLabel, { color: theme.textSecondary }]}>
                  Available
                </Text>
              </View>
            );
          })}
        </View>
      </View>

      <View style={[styles.addCard, { backgroundColor: theme.backgroundSecondary }]}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Add Code by Category</Text>
        
        <View style={styles.denomRow}>
          {["10", "50", "100", "500"].map((d) => (
            <Pressable
              key={d}
              style={[
                styles.denomButton,
                {
                  backgroundColor:
                    newDenom === d ? DiamondColors.primary : theme.backgroundTertiary,
                },
              ]}
              onPress={() => setNewDenom(d)}
            >
              <Text
                style={[
                  styles.denomText,
                  { color: newDenom === d ? "#fff" : theme.text },
                ]}
              >
                Rs.{d}
              </Text>
            </Pressable>
          ))}
        </View>
        
        <TextInput
          style={[styles.input, { color: theme.text, backgroundColor: theme.backgroundRoot }]}
          placeholder={`Enter Rs.${newDenom} Google Play Code`}
          placeholderTextColor={theme.textSecondary}
          value={newCode}
          onChangeText={setNewCode}
          autoCapitalize="characters"
        />
        
        <Pressable
          style={({ pressed }) => [
            styles.addButton,
            pressed && styles.buttonPressed,
          ]}
          onPress={handleAddCode}
          disabled={isLoading}
        >
          <LinearGradient
            colors={[DiamondColors.success, "#28A745"]}
            style={styles.buttonGradient}
          >
            <Feather name="plus" size={20} color="#fff" />
            <Text style={styles.addButtonText}>Add Rs.{newDenom} Code</Text>
          </LinearGradient>
        </Pressable>
      </View>

      <Text style={[styles.sectionTitle, { color: theme.text, marginTop: Spacing.xl }]}>
        Available Codes ({codes.filter((c) => !c.isRedeemed).length})
      </Text>
      
      {codes.filter((c) => !c.isRedeemed).length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="inbox" size={48} color={theme.textSecondary} />
          <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
            No codes available
          </Text>
        </View>
      ) : (
        codes.filter((c) => !c.isRedeemed).map((item) => (
          <View key={item.id} style={[styles.codeCard, { backgroundColor: theme.backgroundSecondary }]}>
            <View style={styles.codeInfo}>
              <Text style={[styles.codeText, { color: theme.text }]}>{item.code}</Text>
              <Text style={[styles.codeDenom, { color: DiamondColors.gold }]}>
                Rs.{item.denomination}
              </Text>
            </View>
            <Pressable
              style={styles.deleteButton}
              onPress={() => handleDeleteCode(item.id)}
            >
              <Feather name="trash-2" size={20} color={DiamondColors.error} />
            </Pressable>
          </View>
        ))
      )}
    </>
  );

  const handleSendTokens = async () => {
    if (!sendTokenUid.trim()) {
      Alert.alert("Error", "Please enter a User UID");
      return;
    }
    if (!sendTokenAmount.trim() || parseInt(sendTokenAmount) <= 0) {
      Alert.alert("Error", "Please enter a valid token amount");
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(new URL("/api/admin/send-tokens", apiUrl).toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          uid: sendTokenUid.trim().toUpperCase(),
          tokens: parseInt(sendTokenAmount),
          adminId,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setSendTokenUid("");
        setSendTokenAmount("");
        Alert.alert("Success", `Sent ${sendTokenAmount} tokens to ${sendTokenUid.trim().toUpperCase()}`);
      } else {
        Alert.alert("Error", data.error || "Failed to send tokens");
      }
    } catch (error) {
      Alert.alert("Error", "Failed to send tokens");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBlockUserDirect = async (referralCode: string) => {
    Alert.alert("Block User", `Block user with code ${referralCode}?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Block",
        style: "destructive",
        onPress: async () => {
          setIsLoading(true);
          try {
            const response = await fetch(new URL("/api/admin/block", apiUrl).toString(), {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                uid: referralCode,
                reason: "Blocked by admin",
                adminId,
                blockType: "misbehave",
              }),
            });
            
            const data = await response.json();
            
            if (response.ok && data.success) {
              fetchData();
              Alert.alert("Success", "User blocked");
            } else {
              Alert.alert("Error", data.error || "Failed to block user");
            }
          } catch (error) {
            Alert.alert("Error", "Failed to block user");
          } finally {
            setIsLoading(false);
          }
        },
      },
    ]);
  };

  const isUserBlockedCheck = (referralCode: string): boolean => {
    return blockedUsers.some((b) => b.uid === referralCode);
  };

  const renderUsersTab = () => (
    <>
      <View style={[styles.addCard, { backgroundColor: theme.backgroundSecondary }]}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Send Tokens to User</Text>
        <TextInput
          style={[styles.input, { backgroundColor: theme.backgroundTertiary, color: theme.text }]}
          placeholder="User UID (e.g., RCW12AB34CD)"
          placeholderTextColor={theme.textSecondary}
          value={sendTokenUid}
          onChangeText={setSendTokenUid}
        />
        <TextInput
          style={[styles.input, { backgroundColor: theme.backgroundTertiary, color: theme.text }]}
          placeholder="Token Amount"
          placeholderTextColor={theme.textSecondary}
          value={sendTokenAmount}
          onChangeText={setSendTokenAmount}
          keyboardType="numeric"
        />
        <Pressable
          style={({ pressed }) => [styles.addButton, pressed && styles.buttonPressed]}
          onPress={handleSendTokens}
          disabled={isLoading}
        >
          <LinearGradient
            colors={[DiamondColors.gold, DiamondColors.goldDark]}
            style={styles.buttonGradient}
          >
            <Feather name="send" size={18} color="#000" />
            <Text style={styles.buttonText}>
              {isLoading ? "Sending..." : "Send Tokens"}
            </Text>
          </LinearGradient>
        </Pressable>
      </View>

      <Text style={[styles.sectionTitle, { color: theme.text, marginTop: Spacing.xl }]}>
        All Users ({allUsers.length})
      </Text>
      
      {allUsers.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="users" size={48} color={theme.textSecondary} />
          <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
            No users registered yet
          </Text>
        </View>
      ) : (
        allUsers.map((user) => {
          const isBlocked = isUserBlockedCheck(user.referralCode);
          return (
            <View
              key={user.id}
              style={[
                styles.userCard,
                { backgroundColor: theme.backgroundSecondary },
                isBlocked && styles.blockedCard,
              ]}
            >
              <View style={styles.userInfo}>
                <Text style={[styles.userUid, { color: isBlocked ? DiamondColors.error : DiamondColors.primary }]}>
                  {user.referralCode}
                </Text>
                <Text style={[styles.userDetails, { color: theme.textSecondary }]}>
                  Tokens: {user.tokenBalance} | Earned: {user.totalEarned} | Spent: {user.totalSpent}
                </Text>
                <Text style={[styles.userDate, { color: theme.textTertiary }]}>
                  Joined: {new Date(user.createdAt).toLocaleDateString()}
                </Text>
              </View>
              {isBlocked ? (
                <Pressable
                  style={[styles.unblockButton, { backgroundColor: DiamondColors.success }]}
                  onPress={() => handleUnblockUser(user.referralCode)}
                >
                  <Feather name="unlock" size={16} color="#fff" />
                </Pressable>
              ) : (
                <Pressable
                  style={[styles.blockButton, { backgroundColor: DiamondColors.error }]}
                  onPress={() => handleBlockUserDirect(user.referralCode)}
                >
                  <Feather name="slash" size={16} color="#fff" />
                </Pressable>
              )}
            </View>
          );
        })
      )}
    </>
  );

  const renderBlockedTab = () => (
    <>
      <View style={[styles.addCard, { backgroundColor: theme.backgroundSecondary }]}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Block User by UID</Text>
        
        <TextInput
          style={[styles.input, { color: theme.text, backgroundColor: theme.backgroundRoot }]}
          placeholder="Enter User UID (e.g., RCW1A2B3C4D)"
          placeholderTextColor={theme.textSecondary}
          value={blockUid}
          onChangeText={setBlockUid}
          autoCapitalize="characters"
        />
        
        <TextInput
          style={[styles.input, { color: theme.text, backgroundColor: theme.backgroundRoot }]}
          placeholder="Reason (optional)"
          placeholderTextColor={theme.textSecondary}
          value={blockReason}
          onChangeText={setBlockReason}
        />
        
        <Text style={[styles.sectionTitle, { color: theme.text, marginTop: Spacing.md }]}>Block Type</Text>
        <View style={styles.blockTypeRow}>
          {[
            { key: "misbehave", label: "Misbehave" },
            { key: "mod_apk", label: "MOD APK" },
            { key: "third_party", label: "Third Party" },
          ].map((t) => (
            <Pressable
              key={t.key}
              style={[
                styles.blockTypeButton,
                { backgroundColor: blockType === t.key ? DiamondColors.error : theme.backgroundTertiary },
              ]}
              onPress={() => setBlockType(t.key)}
            >
              <Text style={[styles.blockTypeText, { color: blockType === t.key ? "#fff" : theme.textSecondary }]}>
                {t.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <Pressable
          style={({ pressed }) => [
            styles.addButton,
            pressed && styles.buttonPressed,
          ]}
          onPress={handleBlockUser}
          disabled={isLoading}
        >
          <LinearGradient
            colors={[DiamondColors.error, "#C62828"]}
            style={styles.buttonGradient}
          >
            <Feather name="slash" size={20} color="#fff" />
            <Text style={styles.addButtonText}>Block User</Text>
          </LinearGradient>
        </Pressable>
      </View>

      <Text style={[styles.sectionTitle, { color: theme.text, marginTop: Spacing.xl }]}>
        Blocked Users ({blockedUsers.length})
      </Text>
      
      {blockedUsers.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="check-circle" size={48} color={DiamondColors.success} />
          <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
            No blocked users
          </Text>
        </View>
      ) : (
        blockedUsers.map((item) => (
          <View key={item.id} style={[styles.codeCard, { backgroundColor: theme.backgroundSecondary }]}>
            <View style={styles.codeInfo}>
              <Text style={[styles.codeText, { color: DiamondColors.error }]}>{item.uid}</Text>
              <Text style={[styles.codeDenom, { color: theme.textSecondary }]}>
                {item.reason || "No reason"}
              </Text>
            </View>
            <Pressable
              style={[styles.unblockButton, { backgroundColor: DiamondColors.success }]}
              onPress={() => handleUnblockUser(item.uid)}
            >
              <Feather name="unlock" size={16} color="#fff" />
            </Pressable>
          </View>
        ))
      )}
    </>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <ScrollView
        contentContainerStyle={[
          styles.listContent,
          { paddingTop: headerHeight + Spacing.lg, paddingBottom: insets.bottom + Spacing.xl },
        ]}
      >
        <View style={styles.tabContainer}>
          <Pressable
            style={[
              styles.tab,
              activeTab === "codes" && { backgroundColor: DiamondColors.primary },
            ]}
            onPress={() => setActiveTab("codes")}
          >
            <Feather
              name="gift"
              size={16}
              color={activeTab === "codes" ? "#fff" : theme.textSecondary}
            />
            <Text
              style={[
                styles.tabText,
                { color: activeTab === "codes" ? "#fff" : theme.textSecondary },
              ]}
            >
              Codes
            </Text>
          </Pressable>
          <Pressable
            style={[
              styles.tab,
              activeTab === "users" && { backgroundColor: DiamondColors.gold },
            ]}
            onPress={() => setActiveTab("users")}
          >
            <Feather
              name="users"
              size={16}
              color={activeTab === "users" ? "#000" : theme.textSecondary}
            />
            <Text
              style={[
                styles.tabText,
                { color: activeTab === "users" ? "#000" : theme.textSecondary },
              ]}
            >
              Users
            </Text>
          </Pressable>
          <Pressable
            style={[
              styles.tab,
              activeTab === "blocked" && { backgroundColor: DiamondColors.error },
            ]}
            onPress={() => setActiveTab("blocked")}
          >
            <Feather
              name="slash"
              size={16}
              color={activeTab === "blocked" ? "#fff" : theme.textSecondary}
            />
            <Text
              style={[
                styles.tabText,
                { color: activeTab === "blocked" ? "#fff" : theme.textSecondary },
              ]}
            >
              Blocked
            </Text>
          </Pressable>
        </View>

        {activeTab === "codes" ? renderCodesTab() : activeTab === "users" ? renderUsersTab() : renderBlockedTab()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
  },
  listContent: {
    paddingHorizontal: Spacing.lg,
  },
  loginCard: {
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
  },
  cardGradient: {
    padding: Spacing.xl,
    alignItems: "center",
  },
  icon: {
    marginBottom: Spacing.lg,
  },
  title: {
    ...Typography.h2,
    marginBottom: Spacing.xl,
  },
  input: {
    width: "100%",
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
    marginBottom: Spacing.md,
  },
  loginButton: {
    width: "100%",
    marginTop: Spacing.md,
  },
  buttonGradient: {
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: Spacing.sm,
  },
  buttonPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  buttonText: {
    color: "#000",
    fontSize: 16,
    fontWeight: "700",
  },
  tabContainer: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  tab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.xs,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
    backgroundColor: "rgba(255,255,255,0.1)",
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600",
  },
  statsContainer: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    ...Typography.h4,
    marginBottom: Spacing.md,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  statCard: {
    flex: 1,
    minWidth: "45%",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
  },
  statDenom: {
    ...Typography.h4,
    marginBottom: Spacing.xs,
  },
  statValue: {
    ...Typography.h2,
  },
  statLabel: {
    ...Typography.small,
  },
  addCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  denomRow: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  denomButton: {
    flex: 1,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.xs,
    alignItems: "center",
  },
  denomText: {
    fontWeight: "600",
    fontSize: 14,
  },
  addButton: {
    overflow: "hidden",
    borderRadius: BorderRadius.sm,
  },
  addButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  codeCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.sm,
  },
  codeInfo: {
    flex: 1,
  },
  codeText: {
    ...Typography.body,
    fontFamily: "monospace",
    fontWeight: "600",
  },
  codeDenom: {
    ...Typography.small,
    marginTop: Spacing.xs,
  },
  deleteButton: {
    padding: Spacing.sm,
  },
  unblockButton: {
    padding: Spacing.sm,
    borderRadius: BorderRadius.xs,
  },
  userCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.sm,
  },
  userInfo: {
    flex: 1,
  },
  userUid: {
    fontSize: 16,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  userDetails: {
    fontSize: 12,
    marginTop: Spacing.xs,
  },
  userDate: {
    fontSize: 11,
    marginTop: 2,
  },
  blockButton: {
    padding: Spacing.sm,
    borderRadius: BorderRadius.xs,
  },
  blockedCard: {
    borderWidth: 1,
    borderColor: "rgba(255, 59, 48, 0.3)",
  },
  emptyContainer: {
    alignItems: "center",
    paddingVertical: Spacing["4xl"],
  },
  emptyText: {
    ...Typography.body,
    marginTop: Spacing.md,
  },
  blockTypeRow: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  blockTypeButton: {
    flex: 1,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.xs,
    alignItems: "center",
  },
  blockTypeText: {
    fontSize: 12,
    fontWeight: "600",
  },
});
