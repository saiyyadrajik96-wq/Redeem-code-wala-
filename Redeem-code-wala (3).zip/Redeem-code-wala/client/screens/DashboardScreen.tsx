import React, { useEffect, useState, useCallback } from "react";
import { View, StyleSheet, ScrollView, RefreshControl, Text } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { TokenBadge } from "@/components/TokenBadge";
import { DiamondCard } from "@/components/DiamondCard";
import { CheckinButton } from "@/components/CheckinButton";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors, Typography } from "@/constants/theme";
import {
  initializeUser,
  getTokens,
  getCheckinData,
  canCheckinToday,
  performDailyCheckin,
  TokenData,
} from "@/lib/storage";

function formatDate(date: Date): string {
  const options: Intl.DateTimeFormatOptions = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return date.toLocaleDateString("en-IN", options);
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
}

const REWARD_STOCK = [
  { denomination: 10, stock: 50 },
  { denomination: 50, stock: 25 },
  { denomination: 100, stock: 15 },
  { denomination: 500, stock: 5 },
  { denomination: 1000, stock: 2 },
];

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const [tokens, setTokens] = useState<TokenData>({ balance: 0, totalEarned: 0, totalSpent: 0 });
  const [streak, setStreak] = useState(0);
  const [canCheckin, setCanCheckin] = useState(true);
  const [checkinLoading, setCheckinLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const loadData = useCallback(async () => {
    await initializeUser();
    const tokenData = await getTokens();
    setTokens(tokenData);

    const checkinData = await getCheckinData();
    if (checkinData) {
      setStreak(checkinData.streak);
    }

    const canDo = await canCheckinToday();
    setCanCheckin(canDo);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleCheckin = async () => {
    setCheckinLoading(true);
    try {
      const result = await performDailyCheckin();
      if (result.success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setStreak(result.streak);
        setCanCheckin(false);
        const newTokens = await getTokens();
        setTokens(newTokens);
      }
    } finally {
      setCheckinLoading(false);
    }
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.xl,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          tintColor={theme.primary}
        />
      }
    >
      <View style={styles.dateTimeContainer}>
        <View style={[styles.dateTimeCard, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="calendar" size={18} color={DiamondColors.primary} />
          <Text style={[styles.dateText, { color: theme.text }]}>
            {formatDate(currentTime)}
          </Text>
        </View>
        <View style={[styles.timeCard, { backgroundColor: theme.backgroundSecondary }]}>
          <Feather name="clock" size={18} color={DiamondColors.gold} />
          <Text style={[styles.timeText, { color: DiamondColors.gold }]}>
            {formatTime(currentTime)}
          </Text>
        </View>
      </View>

      <LinearGradient
        colors={["rgba(10, 132, 255, 0.15)", "rgba(255, 215, 0, 0.08)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.balanceCard}
      >
        <View style={styles.balanceHeader}>
          <ThemedText style={[styles.balanceLabel, { color: theme.textSecondary }]}>
            Your Balance
          </ThemedText>
          <View style={styles.diamondIcon}>
            <Feather name="award" size={20} color={theme.gold} />
          </View>
        </View>
        <TokenBadge balance={tokens.balance} size="large" />
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <ThemedText style={[styles.statValue, { color: theme.success }]}>
              +{tokens.totalEarned.toLocaleString()}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Total Earned
            </ThemedText>
          </View>
          <View style={[styles.statDivider, { backgroundColor: theme.cardBorder }]} />
          <View style={styles.statItem}>
            <ThemedText style={[styles.statValue, { color: theme.error }]}>
              -{tokens.totalSpent.toLocaleString()}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Total Spent
            </ThemedText>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.section}>
        <CheckinButton
          streak={streak}
          canCheckin={canCheckin}
          onCheckin={handleCheckin}
          loading={checkinLoading}
        />
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <ThemedText type="h4">Stock Alert</ThemedText>
          <View style={[styles.liveBadge, { backgroundColor: theme.error + "20" }]}>
            <View style={[styles.liveDot, { backgroundColor: theme.error }]} />
            <ThemedText style={[styles.liveText, { color: theme.error }]}>
              Live
            </ThemedText>
          </View>
        </View>

        <View style={styles.stockList}>
          {REWARD_STOCK.map((item) => (
            <View
              key={item.denomination}
              style={[styles.stockItem, { borderColor: theme.cardBorder }]}
            >
              <View style={styles.stockLeft}>
                <Feather name="credit-card" size={16} color={theme.gold} />
                <ThemedText style={styles.stockDenom}>
                  Rs {item.denomination}
                </ThemedText>
              </View>
              <View
                style={[
                  styles.stockBadge,
                  {
                    backgroundColor:
                      item.stock > 10
                        ? theme.success + "20"
                        : item.stock > 0
                          ? theme.warning + "20"
                          : theme.error + "20",
                  },
                ]}
              >
                <ThemedText
                  style={[
                    styles.stockCount,
                    {
                      color:
                        item.stock > 10
                          ? theme.success
                          : item.stock > 0
                            ? theme.warning
                            : theme.error,
                    },
                  ]}
                >
                  {item.stock} left
                </ThemedText>
              </View>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <ThemedText type="h4">Quick Actions</ThemedText>
        </View>

        <View style={styles.actionsGrid}>
          <DiamondCard variant="primary" style={styles.actionCard}>
            <View style={[styles.actionIcon, { backgroundColor: theme.primary + "30" }]}>
              <Feather name="play" size={24} color={theme.primary} />
            </View>
            <ThemedText style={styles.actionTitle}>Play Games</ThemedText>
            <ThemedText style={[styles.actionDesc, { color: theme.textSecondary }]}>
              Earn tokens
            </ThemedText>
          </DiamondCard>

          <DiamondCard variant="gold" style={styles.actionCard}>
            <View style={[styles.actionIcon, { backgroundColor: theme.gold + "30" }]}>
              <Feather name="gift" size={24} color={theme.gold} />
            </View>
            <ThemedText style={styles.actionTitle}>Redeem</ThemedText>
            <ThemedText style={[styles.actionDesc, { color: theme.textSecondary }]}>
              Get rewards
            </ThemedText>
          </DiamondCard>

          <DiamondCard variant="default" style={styles.actionCard}>
            <View style={[styles.actionIcon, { backgroundColor: theme.success + "30" }]}>
              <Feather name="users" size={24} color={theme.success} />
            </View>
            <ThemedText style={styles.actionTitle}>Refer</ThemedText>
            <ThemedText style={[styles.actionDesc, { color: theme.textSecondary }]}>
              Invite friends
            </ThemedText>
          </DiamondCard>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  dateTimeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  dateTimeCard: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  timeCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  dateText: {
    fontSize: 12,
    fontWeight: "500",
  },
  timeText: {
    fontSize: 14,
    fontWeight: "700",
    fontFamily: "monospace",
  },
  balanceCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: "rgba(10, 132, 255, 0.2)",
    alignItems: "center",
  },
  balanceHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  balanceLabel: {
    fontSize: 14,
    marginRight: Spacing.sm,
  },
  diamondIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "rgba(255, 215, 0, 0.15)",
    alignItems: "center",
    justifyContent: "center",
  },
  statsRow: {
    flexDirection: "row",
    marginTop: Spacing.xl,
    paddingTop: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.1)",
    width: "100%",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
  },
  statDivider: {
    width: 1,
    height: "100%",
  },
  statValue: {
    fontSize: 16,
    fontWeight: "700",
  },
  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  section: {
    marginTop: Spacing.xl,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: Spacing.md,
  },
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    gap: 6,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  liveText: {
    fontSize: 12,
    fontWeight: "600",
  },
  stockList: {
    gap: Spacing.sm,
  },
  stockItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  stockLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  stockDenom: {
    fontSize: 14,
    fontWeight: "600",
  },
  stockBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  stockCount: {
    fontSize: 12,
    fontWeight: "600",
  },
  actionsGrid: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  actionCard: {
    flex: 1,
    alignItems: "center",
    padding: Spacing.lg,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: "600",
    textAlign: "center",
  },
  actionDesc: {
    fontSize: 11,
    textAlign: "center",
    marginTop: 2,
  },
});
