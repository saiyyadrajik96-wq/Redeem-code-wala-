import React, { useState, useEffect, useCallback } from "react";
import { View, StyleSheet, FlatList, Alert, RefreshControl, Pressable, Text } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { useNavigation } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { DiamondCard } from "@/components/DiamondCard";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, DiamondColors } from "@/constants/theme";
import type { ProfileStackParamList } from "@/navigation/ProfileStackNavigator";
import {
  getUser,
  getTokens,
  getRewardsHistory,
  getGameSessions,
  UserData,
  TokenData,
  RewardItem,
  GameSession,
} from "@/lib/storage";

type HistoryItem =
  | { type: "reward"; data: RewardItem }
  | { type: "game"; data: GameSession };

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const navigation = useNavigation<NativeStackNavigationProp<ProfileStackParamList>>();

  const [user, setUser] = useState<UserData | null>(null);
  const [tokens, setTokens] = useState<TokenData>({ balance: 0, totalEarned: 0, totalSpent: 0 });
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    const userData = await getUser();
    setUser(userData);

    const tokenData = await getTokens();
    setTokens(tokenData);

    const rewards = await getRewardsHistory();
    const games = await getGameSessions();

    const combined: HistoryItem[] = [
      ...rewards.map((r) => ({ type: "reward" as const, data: r })),
      ...games.slice(0, 20).map((g) => ({ type: "game" as const, data: g })),
    ].sort((a, b) => {
      const dateA = a.type === "reward" ? a.data.redeemedAt : a.data.playedAt;
      const dateB = b.type === "reward" ? b.data.redeemedAt : b.data.playedAt;
      return new Date(dateB).getTime() - new Date(dateA).getTime();
    });

    setHistory(combined);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleCopyCode = async (code: string) => {
    await Clipboard.setStringAsync(code);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert("Copied!", "Code copied to clipboard");
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatPlayTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins} min${mins !== 1 ? "s" : ""}`;
  };

  const renderHistoryItem = ({ item }: { item: HistoryItem }) => {
    if (item.type === "reward") {
      return (
        <DiamondCard
          variant="gold"
          style={styles.historyCard}
          onPress={() => handleCopyCode(item.data.code)}
        >
          <View style={styles.historyHeader}>
            <View style={[styles.historyIcon, { backgroundColor: theme.gold + "30" }]}>
              <Feather name="gift" size={18} color={theme.gold} />
            </View>
            <View style={styles.historyContent}>
              <ThemedText style={styles.historyTitle}>
                Rs {item.data.denomination} Redeemed
              </ThemedText>
              <ThemedText style={[styles.historyDate, { color: theme.textSecondary }]}>
                {formatDate(item.data.redeemedAt)}
              </ThemedText>
            </View>
            <View style={[styles.tapBadge, { backgroundColor: theme.backgroundTertiary }]}>
              <Feather name="copy" size={12} color={theme.textSecondary} />
            </View>
          </View>
          <View style={[styles.codeBox, { backgroundColor: theme.backgroundRoot }]}>
            <ThemedText style={[styles.codeText, { color: theme.gold }]}>
              {item.data.code}
            </ThemedText>
          </View>
        </DiamondCard>
      );
    }

    return (
      <DiamondCard variant="primary" style={styles.historyCard}>
        <View style={styles.historyHeader}>
          <View style={[styles.historyIcon, { backgroundColor: theme.primary + "30" }]}>
            <Feather name="play" size={18} color={theme.primary} />
          </View>
          <View style={styles.historyContent}>
            <ThemedText style={styles.historyTitle}>
              {item.data.gameName}
            </ThemedText>
            <ThemedText style={[styles.historyDate, { color: theme.textSecondary }]}>
              {formatDate(item.data.playedAt)} - {formatPlayTime(item.data.playTime)}
            </ThemedText>
          </View>
          <View style={[styles.tokensBadge, { backgroundColor: theme.gold + "20" }]}>
            <Feather name="hexagon" size={12} color={theme.gold} />
            <ThemedText style={[styles.tokensText, { color: theme.gold }]}>
              +{item.data.tokensEarned}
            </ThemedText>
          </View>
        </View>
      </DiamondCard>
    );
  };

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <View style={[styles.emptyIcon, { backgroundColor: theme.backgroundSecondary }]}>
        <Feather name="clock" size={48} color={theme.textSecondary} />
      </View>
      <ThemedText type="h4" style={styles.emptyTitle}>
        No Activity Yet
      </ThemedText>
      <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
        Start playing games and earning rewards!
      </ThemedText>
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <LinearGradient
        colors={["rgba(10, 132, 255, 0.15)", "rgba(255, 215, 0, 0.08)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.profileCard}
      >
        <View style={[styles.avatar, { backgroundColor: theme.primary }]}>
          <Feather name="user" size={32} color="#FFFFFF" />
        </View>
        <ThemedText type="h4" style={styles.userName}>
          Diamond Player
        </ThemedText>
        <View style={[styles.uidContainer, { backgroundColor: theme.backgroundRoot }]}>
          <Feather name="hash" size={14} color={DiamondColors.gold} />
          <ThemedText style={[styles.uidText, { color: DiamondColors.gold }]}>
            {user?.uid || "Loading..."}
          </ThemedText>
        </View>
        <ThemedText style={[styles.userId, { color: theme.textSecondary }]}>
          Unique User ID
        </ThemedText>

        <View style={styles.statsGrid}>
          <View style={styles.statBox}>
            <ThemedText style={[styles.statValue, { color: theme.gold }]}>
              {tokens.balance.toLocaleString()}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Balance
            </ThemedText>
          </View>
          <View style={[styles.statDivider, { backgroundColor: theme.cardBorder }]} />
          <View style={styles.statBox}>
            <ThemedText style={[styles.statValue, { color: theme.success }]}>
              {tokens.totalEarned.toLocaleString()}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Earned
            </ThemedText>
          </View>
          <View style={[styles.statDivider, { backgroundColor: theme.cardBorder }]} />
          <View style={styles.statBox}>
            <ThemedText style={[styles.statValue, { color: theme.error }]}>
              {tokens.totalSpent.toLocaleString()}
            </ThemedText>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
              Spent
            </ThemedText>
          </View>
        </View>
      </LinearGradient>

      <Pressable
        style={({ pressed }) => [
          styles.adminButton,
          { backgroundColor: theme.backgroundSecondary },
          pressed && styles.buttonPressed,
        ]}
        onPress={() => navigation.navigate("Admin")}
      >
        <View style={[styles.adminIcon, { backgroundColor: DiamondColors.gold + "20" }]}>
          <Feather name="shield" size={20} color={DiamondColors.gold} />
        </View>
        <View style={styles.adminTextContainer}>
          <Text style={[styles.adminTitle, { color: theme.text }]}>Admin Panel</Text>
          <Text style={[styles.adminDesc, { color: theme.textSecondary }]}>
            Manage redeem codes
          </Text>
        </View>
        <Feather name="chevron-right" size={20} color={theme.textSecondary} />
      </Pressable>

      <View style={styles.sectionHeader}>
        <ThemedText type="h4">Activity History</ThemedText>
      </View>
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <FlatList
        data={history}
        renderItem={renderHistoryItem}
        keyExtractor={(item, index) =>
          item.type === "reward" ? `reward-${item.data.id}` : `game-${item.data.id}`
        }
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
          paddingHorizontal: Spacing.lg,
          flexGrow: 1,
        }}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={theme.primary}
          />
        }
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    marginBottom: Spacing.lg,
  },
  profileCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: "rgba(10, 132, 255, 0.2)",
    alignItems: "center",
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  userName: {
    marginBottom: Spacing.sm,
  },
  uidContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.xs,
  },
  uidText: {
    fontSize: 16,
    fontWeight: "700",
    letterSpacing: 1,
  },
  userId: {
    fontSize: 11,
  },
  statsGrid: {
    flexDirection: "row",
    marginTop: Spacing.xl,
    paddingTop: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.1)",
    width: "100%",
  },
  statBox: {
    flex: 1,
    alignItems: "center",
  },
  statDivider: {
    width: 1,
    height: "100%",
  },
  statValue: {
    fontSize: 18,
    fontWeight: "700",
  },
  statLabel: {
    fontSize: 11,
    marginTop: 4,
  },
  sectionHeader: {
    marginTop: Spacing.xl,
    marginBottom: Spacing.md,
  },
  adminButton: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginTop: Spacing.lg,
  },
  buttonPressed: {
    opacity: 0.8,
  },
  adminIcon: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  adminTextContainer: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  adminTitle: {
    fontSize: 16,
    fontWeight: "600",
  },
  adminDesc: {
    fontSize: 12,
    marginTop: 2,
  },
  historyCard: {
    marginBottom: Spacing.sm,
  },
  historyHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  historyIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  historyContent: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: "600",
  },
  historyDate: {
    fontSize: 12,
    marginTop: 2,
  },
  tapBadge: {
    padding: Spacing.sm,
    borderRadius: BorderRadius.sm,
  },
  tokensBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  tokensText: {
    fontSize: 12,
    fontWeight: "600",
  },
  codeBox: {
    marginTop: Spacing.md,
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
  },
  codeText: {
    fontSize: 14,
    fontWeight: "600",
    letterSpacing: 1,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing["4xl"],
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xl,
  },
  emptyTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  emptyText: {
    textAlign: "center",
    fontSize: 14,
  },
});
