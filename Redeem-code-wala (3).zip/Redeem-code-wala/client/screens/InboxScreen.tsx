import React, { useState, useEffect, useCallback } from "react";
import { View, Text, StyleSheet, ScrollView, Pressable, RefreshControl, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useTheme } from "@/hooks/useTheme";
import { DiamondColors, Spacing, BorderRadius, Typography } from "@/constants/theme";
import { getApiUrl } from "@/lib/query-client";
import { getUser, addTokens, getTokens } from "@/lib/storage";

interface InboxMsg {
  id: string;
  uid: string;
  type: string;
  title: string;
  message: string;
  tokens: number | null;
  claimed: boolean;
  createdAt: string;
}

export default function InboxScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const [messages, setMessages] = useState<InboxMsg[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [userUid, setUserUid] = useState("");
  const apiUrl = getApiUrl();

  const loadMessages = useCallback(async () => {
    const user = await getUser();
    if (!user) return;
    setUserUid(user.referralCode);
    try {
      const res = await fetch(new URL(`/api/user/inbox/${user.referralCode}`, apiUrl).toString());
      const data = await res.json();
      if (Array.isArray(data)) setMessages(data);
    } catch (e) {
      console.error("Inbox fetch error:", e);
    }
  }, [apiUrl]);

  useEffect(() => { loadMessages(); }, [loadMessages]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadMessages();
    setRefreshing(false);
  };

  const handleClaim = async (msg: InboxMsg) => {
    try {
      const res = await fetch(new URL(`/api/user/inbox/claim/${msg.id}`, apiUrl).toString(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uid: userUid }),
      });
      const data = await res.json();
      if (data.success) {
        await addTokens(data.tokens || 0);
        Alert.alert("Claimed!", `You received ${data.tokens} tokens!`);
        await loadMessages();
      } else {
        Alert.alert("Error", data.error || "Failed to claim");
      }
    } catch (e) {
      Alert.alert("Error", "Failed to claim tokens");
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("en-IN", {
      month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
    });
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: insets.bottom + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={theme.primary} />}
    >
      <Text style={[styles.title, { color: theme.text }]}>Inbox</Text>
      <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
        {messages.length > 0 ? `${messages.length} message${messages.length > 1 ? "s" : ""}` : "No messages yet"}
      </Text>

      {messages.length === 0 ? (
        <View style={styles.emptyContainer}>
          <View style={[styles.emptyIcon, { backgroundColor: theme.backgroundSecondary }]}>
            <Feather name="inbox" size={48} color={theme.textSecondary} />
          </View>
          <Text style={[styles.emptyText, { color: theme.textSecondary }]}>Your inbox is empty</Text>
        </View>
      ) : (
        messages.map((msg) => (
          <View
            key={msg.id}
            style={[
              styles.msgCard,
              { backgroundColor: theme.backgroundSecondary },
              msg.type === "block_warning" && { borderLeftWidth: 3, borderLeftColor: DiamondColors.error },
            ]}
          >
            <View style={styles.msgHeader}>
              <View style={[
                styles.msgIcon,
                { backgroundColor: msg.type === "token_gift" ? DiamondColors.gold + "20" : DiamondColors.error + "20" }
              ]}>
                <Feather
                  name={msg.type === "token_gift" ? "gift" : "alert-triangle"}
                  size={20}
                  color={msg.type === "token_gift" ? DiamondColors.gold : DiamondColors.error}
                />
              </View>
              <View style={styles.msgContent}>
                <Text style={[styles.msgTitle, { color: theme.text }]}>{msg.title}</Text>
                <Text style={[styles.msgDate, { color: theme.textSecondary }]}>{formatDate(msg.createdAt)}</Text>
              </View>
              {msg.type === "token_gift" && msg.tokens && msg.tokens > 0 ? (
                <View style={[styles.tokenBadge, { backgroundColor: DiamondColors.gold + "20" }]}>
                  <Feather name="hexagon" size={12} color={DiamondColors.gold} />
                  <Text style={[styles.tokenAmount, { color: DiamondColors.gold }]}>+{msg.tokens}</Text>
                </View>
              ) : null}
            </View>
            <Text style={[styles.msgText, { color: theme.textSecondary }]}>{msg.message}</Text>
            {msg.type === "token_gift" && msg.tokens && msg.tokens > 0 && !msg.claimed ? (
              <Pressable
                style={({ pressed }) => [styles.claimButton, pressed && { opacity: 0.8 }]}
                onPress={() => handleClaim(msg)}
              >
                <LinearGradient
                  colors={[DiamondColors.gold, DiamondColors.goldDark]}
                  style={styles.claimGradient}
                >
                  <Feather name="download" size={16} color="#000" />
                  <Text style={styles.claimText}>Claim Tokens</Text>
                </LinearGradient>
              </Pressable>
            ) : msg.claimed ? (
              <View style={[styles.claimedBadge, { backgroundColor: DiamondColors.success + "20" }]}>
                <Feather name="check-circle" size={14} color={DiamondColors.success} />
                <Text style={[styles.claimedText, { color: DiamondColors.success }]}>Claimed</Text>
              </View>
            ) : null}
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { ...Typography.h3, marginBottom: Spacing.xs },
  subtitle: { ...Typography.small, marginBottom: Spacing.xl },
  emptyContainer: { alignItems: "center", paddingVertical: Spacing["5xl"] },
  emptyIcon: { width: 100, height: 100, borderRadius: 50, alignItems: "center", justifyContent: "center", marginBottom: Spacing.xl },
  emptyText: { ...Typography.body },
  msgCard: { padding: Spacing.lg, borderRadius: BorderRadius.md, marginBottom: Spacing.md },
  msgHeader: { flexDirection: "row", alignItems: "center", marginBottom: Spacing.sm },
  msgIcon: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  msgContent: { flex: 1, marginLeft: Spacing.md },
  msgTitle: { fontSize: 16, fontWeight: "600" },
  msgDate: { fontSize: 12, marginTop: 2 },
  msgText: { fontSize: 14, lineHeight: 20, marginBottom: Spacing.md },
  tokenBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs, borderRadius: BorderRadius.full },
  tokenAmount: { fontSize: 14, fontWeight: "700" },
  claimButton: { overflow: "hidden", borderRadius: BorderRadius.sm },
  claimGradient: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: Spacing.sm, paddingVertical: Spacing.md, borderRadius: BorderRadius.sm },
  claimText: { color: "#000", fontSize: 16, fontWeight: "700" },
  claimedBadge: { flexDirection: "row", alignItems: "center", gap: Spacing.xs, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: BorderRadius.sm, alignSelf: "flex-start" },
  claimedText: { fontSize: 14, fontWeight: "600" },
});
