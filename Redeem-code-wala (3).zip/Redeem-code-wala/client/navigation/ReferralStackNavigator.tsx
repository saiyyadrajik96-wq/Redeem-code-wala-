import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import ReferralScreen from "@/screens/ReferralScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type ReferralStackParamList = {
  Referral: undefined;
};

const Stack = createNativeStackNavigator<ReferralStackParamList>();

export default function ReferralStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Referral"
        component={ReferralScreen}
        options={{
          headerTitle: "Refer & Earn",
        }}
      />
    </Stack.Navigator>
  );
}
