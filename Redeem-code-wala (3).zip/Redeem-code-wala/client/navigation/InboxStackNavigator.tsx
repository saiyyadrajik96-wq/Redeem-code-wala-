import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import InboxScreen from "@/screens/InboxScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type InboxStackParamList = {
  Inbox: undefined;
};

const Stack = createNativeStackNavigator<InboxStackParamList>();

export default function InboxStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Inbox"
        component={InboxScreen}
        options={{
          headerTitle: "Inbox",
        }}
      />
    </Stack.Navigator>
  );
}
