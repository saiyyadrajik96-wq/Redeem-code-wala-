import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import GamesScreen from "@/screens/GamesScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type GamesStackParamList = {
  Games: undefined;
};

const Stack = createNativeStackNavigator<GamesStackParamList>();

export default function GamesStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Games"
        component={GamesScreen}
        options={{
          headerTitle: "Game Arena",
        }}
      />
    </Stack.Navigator>
  );
}
