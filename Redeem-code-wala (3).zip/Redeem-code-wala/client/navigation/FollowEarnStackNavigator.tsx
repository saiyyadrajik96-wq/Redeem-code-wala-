import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import FollowEarnScreen from "@/screens/FollowEarnScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type FollowEarnStackParamList = {
  FollowEarn: undefined;
};

const Stack = createNativeStackNavigator<FollowEarnStackParamList>();

export default function FollowEarnStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="FollowEarn"
        component={FollowEarnScreen}
        options={{
          headerTitle: "Follow & Earn",
        }}
      />
    </Stack.Navigator>
  );
}
