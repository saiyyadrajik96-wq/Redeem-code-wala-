import React, { useState, useEffect } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, ActivityIndicator, StyleSheet, Text } from "react-native";
import MainTabNavigator from "@/navigation/MainTabNavigator";
import LoginScreen from "@/screens/LoginScreen";
import InboxScreen from "@/screens/InboxScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { getLoginState, getUser } from "@/lib/storage";
import { Colors, DiamondColors, Spacing, BorderRadius, Typography } from "@/constants/theme";
import { getApiUrl } from "@/lib/query-client";
import { Feather } from "@expo/vector-icons";

export type RootStackParamList = {
  Login: undefined;
  Main: undefined;
  Inbox: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootStackNavigator() {
  const screenOptions = useScreenOptions();
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [blockMessage, setBlockMessage] = useState("");
  const theme = Colors.dark;

  useEffect(() => {
    checkLoginState();
  }, []);

  const checkLoginState = async () => {
    try {
      const loggedIn = await getLoginState();
      setIsLoggedIn(loggedIn);

      if (loggedIn) {
        const user = await getUser();
        if (user?.referralCode) {
          try {
            const apiUrl = getApiUrl();
            const res = await fetch(new URL(`/api/user/blocked/${user.referralCode}`, apiUrl).toString());
            const data = await res.json();
            if (data.blocked) {
              setIsBlocked(true);
              setBlockMessage(data.blockInfo?.reason || "Your account has been blocked.");
            }
          } catch (e) {
            console.error("Block check error:", e);
          }
        }
      }
    } catch (error) {
      console.error("Error checking login state:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginComplete = () => {
    setIsLoggedIn(true);
  };

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={DiamondColors.primary} />
      </View>
    );
  }

  if (isBlocked) {
    return (
      <View style={[styles.blockedContainer, { backgroundColor: theme.backgroundRoot }]}>
        <View style={styles.blockedContent}>
          <View style={styles.blockedIcon}>
            <Feather name="shield-off" size={64} color={DiamondColors.error} />
          </View>
          <Text style={[styles.blockedTitle, { color: DiamondColors.error }]}>
            Account Blocked
          </Text>
          <View style={[styles.blockedCard, { backgroundColor: theme.backgroundSecondary }]}>
            <Text style={[styles.blockedMessage, { color: theme.textSecondary }]}>
              {blockMessage}
            </Text>
          </View>
          <Text style={[styles.blockedFooter, { color: theme.textSecondary }]}>
            REDEEM CODE WALA
          </Text>
        </View>
      </View>
    );
  }

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      {isLoggedIn ? (
        <>
          <Stack.Screen
            name="Main"
            component={MainTabNavigator}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Inbox"
            component={InboxScreen}
            options={{ headerTitle: "Inbox" }}
          />
        </>
      ) : (
        <Stack.Screen
          name="Login"
          options={{ headerShown: false }}
        >
          {() => <LoginScreen onLoginComplete={handleLoginComplete} />}
        </Stack.Screen>
      )}
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  blockedContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
  },
  blockedContent: {
    alignItems: "center",
    maxWidth: 360,
  },
  blockedIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "rgba(255, 59, 48, 0.15)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing["3xl"],
  },
  blockedTitle: {
    ...Typography.h2,
    marginBottom: Spacing.xl,
    textAlign: "center",
  },
  blockedCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing["3xl"],
    borderLeftWidth: 4,
    borderLeftColor: DiamondColors.error,
  },
  blockedMessage: {
    ...Typography.body,
    lineHeight: 24,
    textAlign: "left",
  },
  blockedFooter: {
    ...Typography.small,
    textAlign: "center",
  },
});
