import AsyncStorage from "@react-native-async-storage/async-storage";

const KEYS = {
  USER_DATA: "@diamond_wala_user",
  TOKENS: "@diamond_wala_tokens",
  DAILY_CHECKIN: "@diamond_wala_checkin",
  REFERRAL_CODE: "@diamond_wala_referral",
  REWARDS_HISTORY: "@diamond_wala_rewards",
  GAME_SESSIONS: "@diamond_wala_games",
  IS_LOGGED_IN: "@diamond_wala_logged_in",
};

export async function getLoginState(): Promise<boolean> {
  const data = await AsyncStorage.getItem(KEYS.IS_LOGGED_IN);
  return data === "true";
}

export async function setLoginState(isLoggedIn: boolean): Promise<void> {
  await AsyncStorage.setItem(KEYS.IS_LOGGED_IN, isLoggedIn ? "true" : "false");
}

export async function logout(): Promise<void> {
  await AsyncStorage.setItem(KEYS.IS_LOGGED_IN, "false");
}

export interface UserData {
  id: string;
  uid: string;
  deviceId: string;
  referralCode: string;
  referredBy?: string;
  createdAt: string;
}

export interface TokenData {
  balance: number;
  totalEarned: number;
  totalSpent: number;
}

export interface CheckinData {
  lastCheckin: string;
  streak: number;
}

export interface RewardItem {
  id: string;
  denomination: number;
  code: string;
  redeemedAt: string;
}

export interface GameSession {
  id: string;
  gameId: string;
  gameName: string;
  playTime: number;
  tokensEarned: number;
  playedAt: string;
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

function generateReferralCode(): string {
  return "DW" + Math.random().toString(36).substring(2, 8).toUpperCase();
}

function generateUID(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `RCW${timestamp.slice(-4)}${random}`;
}

export async function initializeUser(): Promise<UserData> {
  const existingUser = await getUser();
  if (existingUser) {
    if (!existingUser.uid) {
      existingUser.uid = generateUID();
      await AsyncStorage.setItem(KEYS.USER_DATA, JSON.stringify(existingUser));
    }
    return existingUser;
  }

  const newUser: UserData = {
    id: generateId(),
    uid: generateUID(),
    deviceId: generateId(),
    referralCode: generateReferralCode(),
    createdAt: new Date().toISOString(),
  };

  await AsyncStorage.setItem(KEYS.USER_DATA, JSON.stringify(newUser));
  await setTokens({ balance: 5, totalEarned: 5, totalSpent: 0 });
  await AsyncStorage.setItem(KEYS.REWARDS_HISTORY, JSON.stringify([]));
  await AsyncStorage.setItem(KEYS.GAME_SESSIONS, JSON.stringify([]));

  return newUser;
}

export async function getUser(): Promise<UserData | null> {
  const data = await AsyncStorage.getItem(KEYS.USER_DATA);
  return data ? JSON.parse(data) : null;
}

export async function getTokens(): Promise<TokenData> {
  const data = await AsyncStorage.getItem(KEYS.TOKENS);
  return data ? JSON.parse(data) : { balance: 0, totalEarned: 0, totalSpent: 0 };
}

export async function setTokens(tokens: TokenData): Promise<void> {
  await AsyncStorage.setItem(KEYS.TOKENS, JSON.stringify(tokens));
}

export async function addTokens(amount: number): Promise<TokenData> {
  const current = await getTokens();
  const updated = {
    balance: current.balance + amount,
    totalEarned: current.totalEarned + amount,
    totalSpent: current.totalSpent,
  };
  await setTokens(updated);
  return updated;
}

export async function spendTokens(amount: number): Promise<TokenData | null> {
  const current = await getTokens();
  if (current.balance < amount) return null;
  
  const updated = {
    balance: current.balance - amount,
    totalEarned: current.totalEarned,
    totalSpent: current.totalSpent + amount,
  };
  await setTokens(updated);
  return updated;
}

export async function getCheckinData(): Promise<CheckinData | null> {
  const data = await AsyncStorage.getItem(KEYS.DAILY_CHECKIN);
  return data ? JSON.parse(data) : null;
}

export async function performDailyCheckin(): Promise<{ success: boolean; tokens: number; streak: number }> {
  const now = new Date();
  const today = now.toISOString().split("T")[0];
  const checkin = await getCheckinData();

  if (checkin) {
    const lastDate = checkin.lastCheckin.split("T")[0];
    if (lastDate === today) {
      return { success: false, tokens: 0, streak: checkin.streak };
    }

    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split("T")[0];

    const newStreak = lastDate === yesterdayStr ? checkin.streak + 1 : 1;
    const baseReward = 50;
    const streakBonus = Math.min(newStreak - 1, 6) * 10;
    const tokens = baseReward + streakBonus;

    await AsyncStorage.setItem(
      KEYS.DAILY_CHECKIN,
      JSON.stringify({ lastCheckin: now.toISOString(), streak: newStreak })
    );
    await addTokens(tokens);

    return { success: true, tokens, streak: newStreak };
  }

  const tokens = 50;
  await AsyncStorage.setItem(
    KEYS.DAILY_CHECKIN,
    JSON.stringify({ lastCheckin: now.toISOString(), streak: 1 })
  );
  await addTokens(tokens);

  return { success: true, tokens, streak: 1 };
}

export async function canCheckinToday(): Promise<boolean> {
  const checkin = await getCheckinData();
  if (!checkin) return true;

  const today = new Date().toISOString().split("T")[0];
  const lastDate = checkin.lastCheckin.split("T")[0];
  return lastDate !== today;
}

export async function getRewardsHistory(): Promise<RewardItem[]> {
  const data = await AsyncStorage.getItem(KEYS.REWARDS_HISTORY);
  return data ? JSON.parse(data) : [];
}

export async function addReward(reward: RewardItem): Promise<void> {
  const history = await getRewardsHistory();
  history.unshift(reward);
  await AsyncStorage.setItem(KEYS.REWARDS_HISTORY, JSON.stringify(history));
}

export async function getGameSessions(): Promise<GameSession[]> {
  const data = await AsyncStorage.getItem(KEYS.GAME_SESSIONS);
  return data ? JSON.parse(data) : [];
}

export async function addGameSession(session: Omit<GameSession, "id">): Promise<GameSession> {
  const sessions = await getGameSessions();
  const newSession: GameSession = {
    ...session,
    id: generateId(),
  };
  sessions.unshift(newSession);
  if (sessions.length > 100) sessions.pop();
  await AsyncStorage.setItem(KEYS.GAME_SESSIONS, JSON.stringify(sessions));
  return newSession;
}

export interface InboxMessage {
  id: string;
  type: "token_gift" | "block_warning" | "system";
  title: string;
  message: string;
  tokens?: number;
  claimed: boolean;
  createdAt: string;
}

const INBOX_KEY = "@diamond_wala_inbox";

export async function getInbox(): Promise<InboxMessage[]> {
  const data = await AsyncStorage.getItem(INBOX_KEY);
  return data ? JSON.parse(data) : [];
}

export async function addInboxMessage(msg: Omit<InboxMessage, "id" | "claimed" | "createdAt">): Promise<InboxMessage> {
  const inbox = await getInbox();
  const newMsg: InboxMessage = {
    ...msg,
    id: generateId(),
    claimed: false,
    createdAt: new Date().toISOString(),
  };
  inbox.unshift(newMsg);
  await AsyncStorage.setItem(INBOX_KEY, JSON.stringify(inbox));
  return newMsg;
}

export async function claimInboxTokens(messageId: string): Promise<boolean> {
  const inbox = await getInbox();
  const msg = inbox.find(m => m.id === messageId);
  if (!msg || msg.claimed || !msg.tokens) return false;
  msg.claimed = true;
  await AsyncStorage.setItem(INBOX_KEY, JSON.stringify(inbox));
  await addTokens(msg.tokens);
  return true;
}

export async function getUnreadInboxCount(): Promise<number> {
  const inbox = await getInbox();
  return inbox.filter(m => !m.claimed && m.tokens && m.tokens > 0).length;
}
